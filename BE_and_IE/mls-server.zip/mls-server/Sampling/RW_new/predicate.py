import numpy as np


'''
type 1. t.A op t'.B
type 2. t.A op c 

op = {=, !=}
'''

class Predicate(object):
    '''
        make sure that col1 <= col2
    '''
    def __init__(self, col1, col2, constant):
        self.col1 = col1
        self.col2 = col2
        self.constant = constant
        if constant != None:
            self.ifConstant = True
        else:
            self.ifConstant = False
        self.pli1 = None
        self.pli2 = None

    def setPLI(self, pli1, pli2):
        self.pli1 = pli1
        if self.ifConstant == False:
            self.pli2 = pli2

    def getCol1(self):
        return self.col1

    def sample(self, id_, seed, value, sample_num):
        selected = []
        if id_ == 0:
            tupleList = self.pli1[value]
        elif id_ == 1:
            tupleList = self.pli2[value]
        else:
            return []
        if tupleList == [] or tupleList == None:
            return []
        if sample_num >= len(tupleList):
            selected = np.array([e for e in tupleList])
        else:
            np.random.seed(seed)
            sc = np.random.choice(len(tupleList), sample_num, replace=False)
            selected = np.array(tupleList)[sc]
        return selected



