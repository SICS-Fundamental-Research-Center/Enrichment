package sics.seiois.mlsserver.biz.der.enrich;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;

import java.io.Serializable;
import java.util.*;

public class BatchEnrichment implements Serializable {

    private static final long serialVersionUID = 495921400006241111L;

    protected KGraph graph;
    protected Table table;
    protected Config config;
    protected Similarity jacc;
    protected Similarity cos;
    protected HashMap<Integer, ImmutablePair<Integer, Double>> HER;
    protected HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER_topK;
    protected HashMap<Integer, ArrayList<Integer>> candsAll;

    private static final Logger logger = LoggerFactory.getLogger(BatchEnrichment.class);

    public BatchEnrichment(KGraph graph, Table table, Config config) {
        this.graph = graph;
        this.table = table;
        this.config = config;
        this.jacc = new Similarity("Jaccard");
        this.cos = new Similarity("Cosine");
        this.candsAll = new HashMap<>();
    }

    public void setGraph(KGraph graph) {
        this.graph = graph;
    }

    public void setTable(Table table_) {
        this.table = table_;
    }

    public HashMap<Integer, ImmutablePair<Integer, Double>> getHER() {
        return this.HER;
    }

    public HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> getHER_topK() {
        return this.HER_topK;
    }

    public Config getConfig() {
        return this.config;
    }

    public Table getTable() {
        return this.table;
    }

    // only for sequential algorithm
    public void prepareAuxStructure() {
        // for HER blocking
        ArrayList<ArrayList<Integer>> paths = config.getPathsBlocking();
        graph.serialize(paths, config.getPathLabelOption());
//        graph.extractAllEnrichedValues(config.getSchemasGraphMap(), config.getPathLabelOption());
        graph.extractAllEnrichedValuesANDVids(config.getSchemasGraphMap(), config.getPathLabelOption());
        graph.constructBlockingForIndex(Config.LIMITER);
        table.serialize(config.getSchemasBlocking());
        table.constructSerialsTokens(config.LIMITER);
        // for Vertex Matching
        graph.loadEmbeddFile(config.getGraphEmbeddPath());
        table.loadEmbeddFile(config.getTableEmbeddPath());
    }

    private ArrayList<Integer> HERBlockingForEachQuery(int queryID) {
//        String query = table.getSerials()[queryID];
        String[] queryTokens_ = table.getSerialsTokens().get(queryID);
        ArrayList<String> queryTokens = new ArrayList<>(Arrays.asList(queryTokens_));
        ArrayList<Integer> cands = graph.blockingForEachQuery(queryTokens, config.getJaccThreshold(), jacc);
        return cands;
    }

    private ArrayList<Integer> HERBlockingForEachQueryBruteForce(int queryID) {
//        String query = table.getSerials()[queryID];
        String[] queryTokens_ = table.getSerialsTokens().get(queryID);
        ArrayList<String> queryTokens = new ArrayList<>(Arrays.asList(queryTokens_));
        ArrayList<Integer> cands = graph.blockingForEachQueryBruteForce(queryTokens, config.getJaccThreshold(), jacc);
        return cands;
    }

    private ArrayList<ImmutablePair<Integer, Double>> VertexMatchingForEachQueryTopK(int queryID, ArrayList<Integer> cands,
                                                                                     PriorityQueue<ImmutablePair<Integer, Double>> queueTopK,
                                                                                     int K) {
        String query = table.getSerials()[queryID];
        String[] queryTokens_ = table.getSerialsTokens().get(queryID);
        ArrayList<String> queryTokens = new ArrayList<>(Arrays.asList(queryTokens_));
        Double[] queryEmbedd = table.getEmbeddings().get(queryID);
        ArrayList<ImmutablePair<Integer, Double>> vertexTopK = graph.getTopKCorrelations(query, queryTokens,
                queryEmbedd, cands, this.jacc, this.cos, 0.2, K, queueTopK);
        return vertexTopK;
    }

    private ImmutablePair<Integer, Double> VertexMatchingForEachQuery(int queryID, ArrayList<Integer> cands) {
//        if (cands.size() != 0) {
//            logger.info("ddddddddddddddddddd");
//        }
        String query = table.getSerials()[queryID];
        String[] queryTokens_ = table.getSerialsTokens().get(queryID);
        ArrayList<String> queryTokens = new ArrayList<>(Arrays.asList(queryTokens_));
        Double[] queryEmbedd = table.getEmbeddings().get(queryID);
        ImmutablePair<Integer, Double> vertexBest = graph.getTopOneCorrelation(query, queryTokens, queryEmbedd, cands,
                this.jacc, this.cos, 0.2);
        return vertexBest;
    }

    protected void PopulateAll(HashMap<Integer, ImmutablePair<Integer, Double>> HER) {
        ArrayList<String> enrichedSchemas = this.config.getEnrichedSchemas();
        graph.dataImputation(HER, this.table, config.getPathLabelOption());
    }

    protected void PopulateAllTopK(HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER_topK) {
        ArrayList<String> enrichedSchemas = this.config.getEnrichedSchemas();
        graph.dataImputationTopK(HER_topK, this.table, this.cos, config.getPathLabelOption());
    }

    public void enrichmentTopK(int K) {
        this.HER_topK = new HashMap<>();
        PriorityQueue<ImmutablePair<Integer, Double>> queueTopK = new PriorityQueue<ImmutablePair<Integer, Double>>(new Comparator<ImmutablePair<Integer, Double>>() {
            @Override
            public int compare(ImmutablePair<Integer, Double> o1, ImmutablePair<Integer, Double> o2) {
                if (o1.right < o2.right) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });
        for (int queryID = 0; queryID < this.table.getTupleNums(); queryID++) {
            ArrayList<Integer> cands = null;
            if (this.config.getIfHEROPT() == 1) {
                cands = this.HERBlockingForEachQuery(queryID);
            } else {
                cands = this.HERBlockingForEachQueryBruteForce(queryID);
            }
            this.candsAll.put(queryID, cands);
            ArrayList<ImmutablePair<Integer, Double>> vertexTopK = this.VertexMatchingForEachQueryTopK(queryID, cands, queueTopK, K);
            if (vertexTopK != null) {
                this.HER_topK.put(queryID, vertexTopK);
            }
        }
        // populate all
        this.PopulateAllTopK(this.HER_topK);
    }

    public void enrichment() {
        this.HER = new HashMap<>();
        for (int queryID = 0; queryID < this.table.getTupleNums(); queryID++) {
            ArrayList<Integer> cands = null;
            if (this.config.getIfHEROPT() == 1) {
                cands = this.HERBlockingForEachQuery(queryID);
            } else {
                cands = this.HERBlockingForEachQueryBruteForce(queryID);
            }
            this.candsAll.put(queryID, cands);
            ImmutablePair<Integer, Double> vertexBest = this.VertexMatchingForEachQuery(queryID, cands);
            if (vertexBest != null) {
                this.HER.put(queryID, vertexBest);
            }
        }
        // populate all
        this.PopulateAll(HER);
    }

}
