package sics.seiois.mlsserver.biz.der.enrich;

import java.io.Serializable;
import java.util.*;
import java.lang.Math;

public class Similarity implements Serializable {

    private static final long serialVersionUID = 104743481156241104L;
        private String option;
        public Similarity(String option) {
            this.option = option;
        }

        /*
            assume s1 and s2 are sets of nonduplicate tokens
         */
        public double jaccardSimilarity(ArrayList<String> s1, ArrayList<String> s2) {
            int intersection = 0;
            HashSet<String> ind = new HashSet<String>();
            for (String t : s1) {
                ind.add(t);
            }
            for (String t : s2) {
                if (ind.contains(t)) {
                    intersection++;
                }
            }
            return intersection * 1.0 / (s1.size() + s2.size() - intersection);
        }

        public double cosineSimilarity(Double[] s1, Double[] s2) {
            double d = 0;
            double n1 = 0;
            double n2 = 0;
            for (int i = 0; i < s1.length; i++) {
                d += s1[i] * s2[i];
                n1 += s1[i] * s1[i];
                n2 += s2[i] * s2[i];
            }
            return d / (Math.sqrt(n1) * Math.sqrt(n2));
        }
}
