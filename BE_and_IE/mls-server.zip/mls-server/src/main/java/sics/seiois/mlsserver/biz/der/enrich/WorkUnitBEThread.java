package sics.seiois.mlsserver.biz.der.enrich;

import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.message.MessageEnrich;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;
import sics.seiois.mlsserver.biz.der.mining.Message;

import java.util.ArrayList;
import java.util.HashMap;

public class WorkUnitBEThread extends Thread {

    private BatchEnrichment batchEnrichment;
    private ArrayList<Table> tables;
    private ArrayList<MessageEnrich> messages;
    private int K;

    // create a satic key
    static Object ob = "aa"; // arbitrary value

    public WorkUnitBEThread(KGraph graph, ArrayList<Table> tables, Config config, int K, ArrayList<MessageEnrich> messages) {
        super();
        // first consider the first table
        this.batchEnrichment = new BatchEnrichment(graph, tables.get(0), config);
        this.tables = tables;
        this.messages = messages;
        this.K = K;
    }

    public BatchEnrichment getBatchEnrichment() {
        return this.batchEnrichment;
    }

    public void setGraph(KGraph graph) {
        this.batchEnrichment.setGraph(graph);
    }

    public ArrayList<Table> getTables() {
        return this.tables;
    }

    @Override
    public void run() {
        ArrayList<MessageEnrich> messages_temp = new ArrayList<>();
        for (Table table: this.tables) {
            batchEnrichment.setTable(table);
            batchEnrichment.enrichmentTopK(this.K);
            HashMap<String, String[]> enrichedB = new HashMap<>();
            for (String attribute: batchEnrichment.getConfig().getEnrichedSchemas()) {
                enrichedB.put(attribute, batchEnrichment.getTable().getColumn(attribute));
            }
            MessageEnrich message = new MessageEnrich(batchEnrichment.getTable().getTidBegin(),
                    batchEnrichment.getTable().getTidEnd(), "", batchEnrichment.getHER_topK());
            messages_temp.add(message);
        }

        synchronized (ob) {
            messages.addAll(messages_temp);
        }
    }


}
