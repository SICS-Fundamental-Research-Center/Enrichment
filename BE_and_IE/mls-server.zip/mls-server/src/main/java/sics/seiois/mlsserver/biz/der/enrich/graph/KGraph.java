package sics.seiois.mlsserver.biz.der.enrich.graph;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashSet;
import java.io.BufferedReader;
import java.util.*;
import java.io.*;

import org.apache.hadoop.fs.ByteBufferReadable;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sics.seiois.mlsserver.biz.der.enrich.Config;
import sics.seiois.mlsserver.biz.der.enrich.Similarity;
import sics.seiois.mlsserver.biz.der.enrich.Utils;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;


public class KGraph implements Serializable{

    private static final long serialVersionUID = 2160087336068112317L;

    private static final Logger logger = LoggerFactory.getLogger(KGraph.class);

    public static final String LIMITOR = "<->";
//    private HashSet<Vertex> nodes;
    private HashMap<Integer, Vertex> nodesMap;
    private HashMap<Integer, String> edgeLabelsMap;

    private String[] serials;
//    private Integer[] serialsVIDs;
    private ArrayList<Integer> centerVIDs; // also serialsVIDs
    private ArrayList<String[]> serialsTokens;
    private HashMap<Integer, Integer> centerVIDsMap;
    private HashMap<String, ArrayList<Integer>> invertedIndex;
    // embeddings
    private ArrayList<Double[]> embeddings;
    private int edgeNum;

    // store the enriched value of each enriched schema for centrial vertices
    private HashMap<String, ArrayList<String>> enrichedValuesForTableSchemas; // the key is the schema from table
    // store the enriched VID of each enriched schema for centrial vertices
    private HashMap<String, ArrayList<Integer>> enrichedVIDsForTableSchemas;

    private void sampleGraph(double sampleRatio) {
        HashMap<Integer, Vertex> nodesMap_sample = new HashMap<>();
        ArrayList<Integer> centerVIDs_sample = new ArrayList<>();
        HashMap<Integer, Integer> centerVIDsMap_sample = new HashMap<>();
        int totalVerticesNum = this.nodesMap.size();
        int sampleVerticesNum = (int)(sampleRatio * totalVerticesNum);
        int countV = 0;
        for (Map.Entry<Integer, Vertex> entry: this.nodesMap.entrySet()) {
            nodesMap_sample.put(entry.getKey(), entry.getValue());
            countV ++;
            if (countV >= sampleVerticesNum) {
                break;
            }
        }
        // remove unrelated edges
        for (Map.Entry<Integer, Vertex> entry: nodesMap_sample.entrySet()) {
            Vertex v = entry.getValue();
            if (v.getType() == 1) {
                centerVIDs_sample.add(entry.getKey());
                centerVIDsMap_sample.put(entry.getKey(), centerVIDs_sample.size() - 1);
            }
            ArrayList<Integer> removedKeys = new ArrayList<>();
            for (Map.Entry<Integer, Edge> entry1: v.getEdges().entrySet()) {
                Vertex v_tgt = entry1.getValue().getDestVertex();
                if (! nodesMap_sample.containsKey(v_tgt.getVid())) {
//                    nodesMap_sample.get(entry.getKey()).getEdges().remove(entry1.getKey());
                    removedKeys.add(entry1.getKey());
                }
            }
            for (Integer removedKey : removedKeys) {
                nodesMap_sample.get(entry.getKey()).getEdges().remove(removedKey);
            }
        }
        // replace the full one
        this.nodesMap = nodesMap_sample;
        this.centerVIDs = centerVIDs_sample;
        this.centerVIDsMap = centerVIDsMap_sample;

    }

    // Lite version (for parallel)
    public KGraph (String[] serials, ArrayList<Integer> centerVIDs, ArrayList<String[]> serialsTokens,
                   HashMap<Integer, Integer> centerVIDsMap, HashMap<String, ArrayList<Integer>> invertedIndex,
                   ArrayList<Double[]> embeddings, int edgeNum, HashMap<String,
            ArrayList<String>> enrichedValuesForTableSchemas) {
        this.nodesMap = null;
        this.edgeLabelsMap = null;
        this.serials = serials;
        this.centerVIDs = centerVIDs;
        this.serialsTokens = serialsTokens;
        this.centerVIDsMap = centerVIDsMap;
        this.invertedIndex = invertedIndex;
        this.embeddings = embeddings;
        this.edgeNum = edgeNum;
        this.enrichedValuesForTableSchemas = enrichedValuesForTableSchemas;
    }

    // Lite version (for parallel)
    public KGraph (String[] serials, ArrayList<Integer> centerVIDs, ArrayList<String[]> serialsTokens,
                   HashMap<Integer, Integer> centerVIDsMap, HashMap<String, ArrayList<Integer>> invertedIndex,
                   ArrayList<Double[]> embeddings, int edgeNum, HashMap<String,
            ArrayList<String>> enrichedValuesForTableSchemas,
                   HashMap<String, ArrayList<Integer>> enrichedVIDsForTableSchemas) {
        this.nodesMap = null;
        this.edgeLabelsMap = null;
        this.serials = serials;
        this.centerVIDs = centerVIDs;
        this.serialsTokens = serialsTokens;
        this.centerVIDsMap = centerVIDsMap;
        this.invertedIndex = invertedIndex;
        this.embeddings = embeddings;
        this.edgeNum = edgeNum;
        this.enrichedValuesForTableSchemas = enrichedValuesForTableSchemas;
        this.enrichedVIDsForTableSchemas = enrichedVIDsForTableSchemas;
    }

    public HashMap<String, ArrayList<String>> getEnrichedValuesForTableSchemas() {
        return this.enrichedValuesForTableSchemas;
    }

    public HashMap<String, ArrayList<Integer>> getEnrichedVIDsForTableSchemas() {
        return this.enrichedVIDsForTableSchemas;
    }

    public HashMap<Integer, Integer> getCenterVIDsMap() {
        return this.centerVIDsMap;
    }

    public ArrayList<Integer> getCenterVIDs() {
        return this.centerVIDs;
    }


    public String[] getSerials() {
        return this.serials;
    }

    public HashMap<String, ArrayList<Integer>> getInvertedIndex() {
        return this.invertedIndex;
    }

    public ArrayList<String[]> getSerialsTokens() {
        return this.serialsTokens;
    }

    public ArrayList<Double[]> getEmbeddings() {
        return this.embeddings;
    }

    public void generateReverseNodesMap() {
        for (Map.Entry<Integer, Vertex> entry : this.nodesMap.entrySet()) {
            Vertex v = entry.getValue();
            for (Map.Entry<Integer, Edge> entry1: v.getEdges().entrySet()) {
                Edge e = entry1.getValue();
                Vertex v_src = v;
                Vertex v_tgt = e.getDestVertex();
                v_tgt.getReverseEdges().put(e.getLabel(), e);
            }
        }
    }

    public HashMap<Integer, Vertex> getNodesMap() {
        return this.nodesMap;
    }

    public int getVertexNum() {
        return this.nodesMap.size();
    }

    public int getEdgeNum() {
        return this.edgeNum;
    }

    private void computeEdgeNum() {
        this.edgeNum = 0;
        for (Map.Entry<Integer, Vertex> entry: this.nodesMap.entrySet()) {
            this.edgeNum += entry.getValue().getEdges().size();
        }
    }

    public void loadEmbeddFile_new(String graphEmbeddFile, String graphId2Index,
                                   HashMap<Integer, Integer> VIDTransform, int vertexNum) {
        this.embeddings = new ArrayList<>(vertexNum);
        try {
            // load id2index mapping
            FileReader fr = new FileReader(graphId2Index);
            BufferedReader br = new BufferedReader(fr);
            String line;
            ArrayList<Integer> id2index = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                Integer vid = Integer.parseInt(line);
                // assume all vids have corresponding vertiex ids
                int vid_transform = VIDTransform.get(vid);
                id2index.add(vid_transform);
            }
            // load embedding files
            FileInputStream inputStream = new FileInputStream(graphEmbeddFile);
            DataInputStream dis = new DataInputStream(inputStream);
            int tupleNum = (int)dis.readDouble();
            int embedDim = (int)dis.readDouble();
            while (dis.available() > 0) {
                for (int z = 0; z < tupleNum; z++) {
                    Double[] embed = new Double[embedDim];
                    for (int z_ = 0; z_ < embedDim; z_++) {
                        embed[z_] = dis.readDouble();
                    }
                    // this.embeddings.add(embed);
                    this.embeddings.set(z, embed);
                }

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void loadEmbeddFile(String graphEmbeddFile) {
        this.embeddings = new ArrayList<>();
        if (graphEmbeddFile.equals("")) {
            int len = this.serials.length;
            for (int i = 0; i < len; i ++) {
                Double[] m = new Double[20];
                for (int z = 0; z < m.length; z++) {
                    m[z] = 1.0;
                }
                this.embeddings.add(m);
            }
            return;
        }
        File file = new File(graphEmbeddFile);
        try {
//            FileReader fr = new FileReader(file);
//            BufferedReader br = new BufferedReader(fr);
//            String line;
//            while ((line = br.readLine()) != null) {
//                String[] embeddStr = line.split(" ");
//                Double[] embed = new Double[embeddStr.length];
//                for (int z = 0; z < embeddStr.length; z++) {
//                    embed[z] = Double.parseDouble(embeddStr[z]);
//                }
//                this.embeddings.add(embed);
//            }
            // load binary file
            FileInputStream inputStream = new FileInputStream(graphEmbeddFile);
            DataInputStream dis = new DataInputStream(inputStream);
            int tupleNum = (int)dis.readFloat();
            int embedDim = (int)dis.readFloat();
//            int count = dis.available();
//            byte[] bbs = new byte[count];
//            int bytes = dis.read(bbs);
//            float[] floats = new float[(int)(bbs.length / 4)];
//            ByteBuffer buffer = ByteBuffer.wrap(bbs);
//            buffer.order(ByteOrder.BIG_ENDIAN);
//            for (int i = 0; i < floats.length; i++) {
//                floats[i] = buffer.getFloat();
//            }
//            for (int z = 0; z < tupleNum; z++) {
//                Double[] embed = new Double[embedDim];
//                for (int z_ = 0; z_ < embedDim; z_++) {
//                    embed[z_] = (double) floats[z * embedDim + z_];
//                }
//                this.embeddings.add(embed);
//            }

            // a slow version
            int partition = 500000;
            for (int rid = 0; rid < tupleNum; rid+=partition) {
                System.out.println("G --------------------------");
                int interval = partition;
                if ((rid + partition) >= tupleNum) {
                    interval = tupleNum - rid;
                }
                byte[] bbs_ = new byte[embedDim * 4 * interval];
                int bytes_ = dis.read(bbs_);
                ByteBuffer buffer_ = ByteBuffer.wrap(bbs_);
                buffer_.order(ByteOrder.BIG_ENDIAN);
                for (int ttid = 0; ttid < interval; ttid++) {
                    Double[] embed = new Double[embedDim];
                    for (int z_ = 0; z_ < embedDim; z_++) {
                        embed[z_] = (double) buffer_.getFloat();
                    }
                    this.embeddings.add(embed);
                }
            }
            System.out.println("G ========================");


//            while (dis.available() > 0) {
//                for (int z = 0; z < tupleNum; z++) {
//                    Double[] embed = new Double[embedDim];
//                    for (int z_ = 0; z_ < embedDim; z_++) {
//                        embed[z_] = (double) dis.readFloat();
//                    }
//                    this.embeddings.add(embed);
//                }
//            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public KGraph(){
//        nodes = new HashSet<>();
        this.nodesMap = new HashMap<Integer, Vertex>();

    }

    public void AddEdge(Vertex v1, Vertex v2, int label){
        //since it's a directed graph
        Vertex v = this.nodesMap.get(v1.getVid());
//        v.getEdges().add(new Edge(v2, label));
        v.getEdges().put(label, new Edge(v1, v2, label));
//        return v1.getEdges().add(new Edge(v2, weight));
        /* If you want to implement an undirected graph,
            add v2.getEdges().add(new Edge(v1, weight)) also */
    }

    public void AddVertex(Vertex v){
//        return nodes.add(v);
        int vid = v.getVid();
        this.nodesMap.put(vid, v);
    }

    /*
        assume graph is a DAG
        load graph from disk
     */
    private void loadTripletFile(String tripletFile, HashMap<Integer, Integer> VIDTransform) {
        File file = new File(tripletFile);
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line;
            while ((line = br.readLine()) != null) {
//                logger.info("line is " + line);
                String[] triplet = line.split(" ");
                int vid_src = Integer.parseInt(triplet[0].trim());
                int eid = Integer.parseInt(triplet[1].trim());
                int vid_tgt = Integer.parseInt(triplet[2].trim());
                int vid_src_transform = VIDTransform.get(vid_src);
//                logger.info(String.valueOf(vid_tgt));
                int vid_tgt_transform = VIDTransform.get(vid_tgt);
                Vertex v_src = this.nodesMap.get(vid_src_transform);
                Vertex v_tgt = this.nodesMap.get(vid_tgt_transform);
                this.AddEdge(v_src, v_tgt, eid);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void loadTripletHDFSFile(String tripletFile, HashMap<Integer, Integer> VIDTransform, FileSystem hdfs) {
        File file = new File(tripletFile);
        try {
            FSDataInputStream inputTxt = hdfs.open(new Path(tripletFile));
            BufferedInputStream bis = new BufferedInputStream(inputTxt);
            InputStreamReader sReader = new InputStreamReader(bis, "UTF-8");
            BufferedReader br = new BufferedReader(sReader);
            String line;
            while ((line = br.readLine()) != null) {
//                logger.info("line is " + line);
                String[] triplet = line.split(" ");
                int vid_src = Integer.parseInt(triplet[0].trim());
                int eid = Integer.parseInt(triplet[1].trim());
                int vid_tgt = Integer.parseInt(triplet[2].trim());
                int vid_src_transform = VIDTransform.get(vid_src);
                logger.info(String.valueOf(vid_tgt));
                int vid_tgt_transform = VIDTransform.get(vid_tgt);
                Vertex v_src = this.nodesMap.get(vid_src_transform);
                Vertex v_tgt = this.nodesMap.get(vid_tgt_transform);
                this.AddEdge(v_src, v_tgt, eid);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void loadEdgeFile(String edgeFile) {
        this.edgeLabelsMap = new HashMap<>();
        File file = new File(edgeFile);
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line;
            while ((line = br.readLine()) != null) {
                String[] einfo = line.split(" "); // eid \t label
                int eid = Integer.parseInt(einfo[0].trim());
                String label = einfo[1].trim();
                this.edgeLabelsMap.put(eid, label);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void loadEdgeHDFSFile(String edgeFile, FileSystem hdfs) {
        this.edgeLabelsMap = new HashMap<>();
        try {
            FSDataInputStream inputTxt = hdfs.open(new Path(edgeFile));
            BufferedInputStream bis = new BufferedInputStream(inputTxt);
            InputStreamReader sReader = new InputStreamReader(bis, "UTF-8");
            BufferedReader br = new BufferedReader(sReader);
            String line;
            while ((line = br.readLine()) != null) {
                String[] einfo = line.split(" "); // eid \t label
                int eid = Integer.parseInt(einfo[0].trim());
                String label = einfo[1].trim();
                this.edgeLabelsMap.put(eid, label);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadVertexHDFSFile(String vertexFile, HashMap<Integer, Integer> VIDTransform, FileSystem hdfs) {
        try {
            FSDataInputStream inputTxt = hdfs.open(new Path(vertexFile));
            BufferedInputStream bis = new BufferedInputStream(inputTxt);
            InputStreamReader sReader = new InputStreamReader(bis, "UTF-8");
            BufferedReader br = new BufferedReader(sReader);
            String line;
            int vidCount = 0;
            while ((line = br.readLine()) != null) {
//                logger.info("line is " + line);
                String[] vinfo = line.split(" "); // vid \t label
                int vid = Integer.parseInt(vinfo[0].trim());
                String label = "";
                if (vinfo.length > 1) {
                    //                    label = vinfo[1];
                    for (int zz = 1; zz < vinfo.length; zz++) {
                        label += vinfo[zz] + " ";
                    }
                    label = label.trim();
                }
                if (!VIDTransform.containsKey(vid)) {
                    VIDTransform.put(vid, vidCount);
                    Vertex v = new Vertex(vidCount, label, 0);
                    this.nodesMap.put(vidCount, v);
                    vidCount ++;
                }

            }
        } catch (Exception e) {
            logger.info("load vertex file error ", e);
            e.printStackTrace();
        }
    }

    private void loadVertexFile(String vertexFile, HashMap<Integer, Integer> VIDTransform) {
        File file = new File(vertexFile);
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line;
            int vidCount = 0;
            while ((line = br.readLine()) != null) {
//                logger.info("line is " + line);
                String[] vinfo = line.split(" "); // vid \t label
                int vid = Integer.parseInt(vinfo[0].trim());
                String label = "";
                if (vinfo.length > 1) {
//                    label = vinfo[1];
                    for (int zz = 1; zz < vinfo.length; zz++) {
                        label += vinfo[zz] + " ";
                    }
                    label = label.trim();
                }
                if (!VIDTransform.containsKey(vid)) {
                    VIDTransform.put(vid, vidCount);
                    Vertex v = new Vertex(vidCount, label, 0);
                    this.nodesMap.put(vidCount, v);
                    vidCount ++;
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadCenterVertexFile(String centerVertexFile, HashMap<Integer, Integer> VIDTransform) {
        File file = new File(centerVertexFile);
        this.centerVIDs = new ArrayList<>();
        this.centerVIDsMap = new HashMap<>();
        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line;
            while ((line = br.readLine()) != null) {
                int vid = Integer.parseInt(line.trim());
                this.centerVIDs.add(VIDTransform.get(vid));
                this.centerVIDsMap.put(VIDTransform.get(vid), this.centerVIDs.size() - 1);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadCenterVertexHDFSFile(String centerVertexFile, HashMap<Integer, Integer> VIDTransform, FileSystem hdfs) {
        File file = new File(centerVertexFile);
        this.centerVIDs = new ArrayList<>();
        this.centerVIDsMap = new HashMap<>();
        try {
            FSDataInputStream inputTxt = hdfs.open(new Path(centerVertexFile));
            BufferedInputStream bis = new BufferedInputStream(inputTxt);
            InputStreamReader sReader = new InputStreamReader(bis, "UTF-8");
            BufferedReader br = new BufferedReader(sReader);

            String line;
            while ((line = br.readLine()) != null) {
                int vid = Integer.parseInt(line.trim());
                this.centerVIDs.add(VIDTransform.get(vid));
                this.centerVIDsMap.put(VIDTransform.get(vid), this.centerVIDs.size() - 1);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadGraph(String graphFile, double sampleRatioGraphBE) {
        // assume graphFile is split by "<->"
        String[] graphInfoFile = graphFile.split(LIMITOR);
        String vertexFile = graphInfoFile[0];
        String edgeFile = graphInfoFile[1];
        String tripletFile = graphInfoFile[2];
        String centerVertexFile = graphInfoFile[3];
        HashMap<Integer, Integer> VIDTransform = new HashMap<>();
        loadVertexFile(vertexFile, VIDTransform);
        loadEdgeFile(edgeFile);
        loadTripletFile(tripletFile, VIDTransform);
        loadCenterVertexFile(centerVertexFile, VIDTransform);

        // statistic edge number
        this.computeEdgeNum();

        // set types of each vertex
        for (int i = 0; i < this.centerVIDs.size(); i++) {
            this.nodesMap.get(this.centerVIDs.get(i)).setType(1);
        }
        // sample
        if (sampleRatioGraphBE != 1.0) {
            this.sampleGraph(sampleRatioGraphBE);
        }
    }


    public void loadGraphHDFS(String graphFile, FileSystem hdfs, double sampleRatioGraphBE) {
        // assume graphFile is split by "<->"
        String[] graphInfoFile = graphFile.split(LIMITOR);
        String vertexFile = graphInfoFile[0];
        String edgeFile = graphInfoFile[1];
        String tripletFile = graphInfoFile[2];
        String centerVertexFile = graphInfoFile[3];
        HashMap<Integer, Integer> VIDTransform = new HashMap<>();
        loadVertexHDFSFile(vertexFile, VIDTransform, hdfs);
        loadEdgeHDFSFile(edgeFile, hdfs);
        loadTripletHDFSFile(tripletFile, VIDTransform, hdfs);
        loadCenterVertexHDFSFile(centerVertexFile, VIDTransform, hdfs);

        // statistic edge number
        this.computeEdgeNum();

        // set types of each vertex
        for (int i = 0; i < this.centerVIDs.size(); i++) {
            this.nodesMap.get(this.centerVIDs.get(i)).setType(1);
        }

        // sample
        if (sampleRatioGraphBE != 1.0) {
            this.sampleGraph(sampleRatioGraphBE);
        }
    }



//    public void loadGraph(String graphFile) {
//        File file = new File(graphFile);
//        try {
//            FileReader fr = new FileReader(file);
//            BufferedReader br = new BufferedReader(fr);
//            String line;
//            ArrayList<String[]> adjList = new ArrayList<String[]>();
//            while ((line = br.readLine()) != null) {
//                String[] vlist = line.split("");
//                adjList.add(vlist);
//            }
////        HashMap<Integer, Vertex> mapVertex = new HashMap<Integer, Vertex>();
//            for (String[] vlist : adjList) {
//                String info = vlist[0];
//                Integer vid = Integer.parseInt(info.split(LIMITOR)[0]);
//                String label = info.split(LIMITOR)[1];
//                Vertex v = new Vertex(vid, label);
//                this.nodesMap.put(vid, v);
//            }
//            // construct the adjacant list
//            for (String[] vlist : adjList) {
//                String info_center = vlist[0];
//                Integer vid_center = Integer.parseInt(info_center.split(LIMITOR)[0]);
//                for (int i = 1; i < vlist.length; i++) {
//                    String info = vlist[i];
//                    Integer vid = Integer.parseInt(info.split(LIMITOR)[0]);
//                    String label = info.split(LIMITOR)[1];
//                    this.AddEdge(this.nodesMap.get(vid_center), this.nodesMap.get(vid), label);
//                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        this.computeEdgeNum();
//    }

    public void serialize(ArrayList<ArrayList<Integer>> paths, String option) {
//        this.serials = new String[this.nodesMap.size()];
        this.serials = new String[this.centerVIDs.size()];
//        for (int vid = 0; vid < this.nodesMap.size(); vid ++) {
        for (int sc = 0; sc < this.centerVIDs.size(); sc++) {
            String s = "";
            int vid = this.centerVIDs.get(sc);
            for(ArrayList<Integer> path: paths) {
                String v_ = this.extractOnePath(vid, path, option);
                s += v_ + " ";
            }
            this.serials[sc] = s.trim();
//            this.serialsVIDs[vid] = vid;
        }
    }

    public void serializeBaseUpdate(HashSet<Integer> affectedVIDs, HashMap<Integer, String> affectedSerials, ArrayList<ArrayList<Integer>> paths, String option) {
        HashMap<Integer, String> potentialAffectedSerials = new HashMap<>();
        HashSet<Integer> potentialAffectedVIDs = new HashSet<>(affectedVIDs);
        for (Integer vid : potentialAffectedVIDs) {
            if (this.nodesMap.get(vid).getType() != 1) {
                affectedVIDs.remove(vid);
                continue;
            }
            int sc = this.centerVIDsMap.get(vid);
            String s = "";
            for (ArrayList<Integer> path : paths) {
                String v_ = this.extractOnePath(vid, path, option);
                s += v_ + " ";
            }
            if (s.equals(this.serials[sc])) { // check whether the serialized vertex has changed.
                affectedVIDs.remove(vid);
            } else {
                affectedSerials.put(vid, s);
            }
        }
    }

    /*
        partition strings to sets of tokens
     */
//    private void generateTokens(String limiter) {
//        this.serialsTokens = new ArrayList<String[]>();
//        for (String record : this.serials) {
//            String[] tokens = record.split(limiter);
//            serialsTokens.add(tokens);
//        }
//    }

    public void constructBlockingForIndex(String limiter) {
        this.serialsTokens = Utils.generateTokens(this.serials, limiter);
        this.invertedIndex = new HashMap<String, ArrayList<Integer>>();
//        for(ArrayList<String> tokens : this.serialsTokens) {
        for (int rid = 0; rid < this.serialsTokens.size(); rid++){
            for (String token : this.serialsTokens.get(rid)) {
                if (this.invertedIndex.containsKey(token)) {
                    this.invertedIndex.get(token).add(rid);
                } else {
                    ArrayList<Integer> rids = new ArrayList<Integer>();
                    rids.add(rid);
                    this.invertedIndex.put(token, rids);
                }
            }
        }
    }

    // compute the correlation
    private double computeCorr(ArrayList<String> queryTokens, Double[] queryEmbedd,
                              String[] vertexTokens, Double[] vertexEmbedd,
                              Similarity jacc, Similarity cos, double alpha) {
        ArrayList<String> vertexTokens_ = new ArrayList<String>();
        double jaccV = jacc.jaccardSimilarity(queryTokens, vertexTokens_);
        double cosV = cos.cosineSimilarity(queryEmbedd, vertexEmbedd);
        return jaccV * alpha + (1 - alpha) * cosV;
    }

    public ArrayList<ImmutablePair<Integer, Double>> getTopKCorrelations(String query, ArrayList<String> queryTokens, Double[] queryEmbedd,
                                                  ArrayList<Integer> cands, Similarity jacc, Similarity cos, double alpha, int K,
                                                  PriorityQueue<ImmutablePair<Integer, Double>> queueTopK) {
        if (cands.size() == 0) {
            return null;
        }
        if (cands.size() <= K){
            ArrayList<ImmutablePair<Integer, Double>> res = new ArrayList<>();
            for (Integer cand :cands) {
                res.add(new ImmutablePair<>(cand, 0.0));
            }
            return res;
        }
        queueTopK.clear();
        for (int i = 0; i < cands.size(); i++) {
            double corr = this.computeCorr(queryTokens, queryEmbedd, this.serialsTokens.get(cands.get(i)), this.embeddings.get(cands.get(i)),
                    jacc, cos, alpha);
            queueTopK.add(new ImmutablePair<>(cands.get(i), corr));
        }
        ArrayList<ImmutablePair<Integer, Double>> results = new ArrayList<>();
        for (int i = 0; i < K; i++) {
            ImmutablePair<Integer, Double> v = queueTopK.poll();
            results.add(v);
        }
        return results;
    }

    public ImmutablePair<Integer, Double> getTopOneCorrelation(String query, ArrayList<String> queryTokens, Double[] queryEmbedd, ArrayList<Integer> cands,
                                     Similarity jacc, Similarity cos, double alpha) {
        if (cands.size() == 0) {
            return null;
        }
        // compute correlation
        int vid_best =  cands.get(0);
        double corr_max = this.computeCorr(queryTokens, queryEmbedd, this.serialsTokens.get(cands.get(0)),
                this.embeddings.get(cands.get(0)) , jacc, cos, alpha);
        for (int i = 1; i < cands.size(); i++) {
            double corr = this.computeCorr(queryTokens,queryEmbedd,this.serialsTokens.get(cands.get(i)),
                    this.embeddings.get(cands.get(i)), jacc, cos,alpha);
            if (corr > corr_max) {
                corr_max = corr;
                vid_best = cands.get(i);
            }
        }
        return new ImmutablePair<>(this.centerVIDs.get(vid_best), corr_max);
    }

    /*
        brute force method
     */
    public ArrayList<Integer> blockingForEachQueryBruteForce(ArrayList<String> query, double simThreshold, Similarity sim) {
        ArrayList<Integer> cands = new ArrayList<>();
        int queryLen = query.size();
        HashSet<Integer> set = new HashSet<>();
        for (int i = 0; i <queryLen; i++) {
            String token = query.get(i);
            ArrayList<Integer> list = this.invertedIndex.get(token);
            if (list != null && list.size() < (this.serialsTokens.size() * 0.3)) {
                for (Integer vid :list) {
                    set.add(vid);
                }
            }
        }

        for (Integer vid : set) {
            ArrayList<String> vertexTokens_ = new ArrayList<>();
            for (String t : this.serialsTokens.get(vid)) {
                vertexTokens_.add(t);
            }
            double simV = sim.jaccardSimilarity(query, vertexTokens_);
            if (simV >=simThreshold) {
                cands.add(vid);
            }
        }
        return cands;
    }

    public ArrayList<Integer> blockingForEachQuery(ArrayList<String> query, double simThreshold, Similarity sim) {
        ArrayList<Integer> cands = new ArrayList<Integer>();
        int queryLen = query.size();
        int num_prefix_tokens = queryLen - (int)(queryLen * simThreshold) + 1;
        if (num_prefix_tokens > queryLen) {
            num_prefix_tokens = queryLen;
        }
        ArrayList<Integer> freqs = new ArrayList<Integer>();
        for (String token : query) {
            if(this.invertedIndex.containsKey(token)) {
                freqs.add(this.invertedIndex.get(token).size());
            } else{
                freqs.add(0);
            }
        }
        PriorityQueue<ImmutablePair<String, Integer>> tokenFreqs = new PriorityQueue<ImmutablePair<String, Integer>>(
                new Comparator<ImmutablePair<String, Integer>>(){
                    @Override
                    public int compare(ImmutablePair<String, Integer> o1, ImmutablePair<String, Integer> o2) {
                        if (o1.getValue() < o2.getValue()) {
                            return -1;
                        } else if (o1.getValue() > o2.getValue()) {
                            return 1;
                        } else {
                            return 0;
                        }
                    }
                }
        );
        for (int i = 0; i < queryLen; i++) {
            ImmutablePair<String, Integer> pair = new ImmutablePair<>(query.get(i), freqs.get(i));
            tokenFreqs.add(pair);
        }
        // extract candidate vertices
        HashSet<Integer> set = new HashSet<Integer>();
        for (int i = 0; i < num_prefix_tokens; i++) {
            String token = tokenFreqs.poll().getKey();
            ArrayList<Integer> list = this.invertedIndex.get(token);
            if (list != null) {
                for (Integer vid : list) {
                    set.add(vid);
                }
            }
        }
        // verify the candidates
        for (Integer vid : set) {
            String[] vertexTokens = this.serialsTokens.get(vid);
            ArrayList<String> vertexTokens_ = new ArrayList<String>();
            for (String t : vertexTokens) {
                vertexTokens_.add(t);
            }
            double simV = sim.jaccardSimilarity(query, vertexTokens_);
            if (simV >= simThreshold) {
                cands.add(vid);
            }
        }

        return cands;
//        // transform cands SC to vids
//        ArrayList<Integer> candsVIDs = new ArrayList<>();
//        for (int i = 0; i < cands.size(); i++) {
////            candsVIDs.add(this.centerVIDsMap.get(cands.get(i)));
//            candsVIDs.add(this.centerVIDs.get(cands.get(i)));
//        }
//        return candsVIDs;
    }

    /*
        pre-extract all values of enriched schemas
     */
    public void extractAllEnrichedValues(HashMap<String, ArrayList<Integer>> schemaGraphMap, String option) {
        this.enrichedValuesForTableSchemas = new HashMap<>();
        for (Map.Entry<String, ArrayList<Integer>> entry : schemaGraphMap.entrySet()) {
            this.enrichedValuesForTableSchemas.put(entry.getKey(), new ArrayList<String>());
            for (Integer vid : this.centerVIDs) {
                String s = this.extractOnePath(vid, entry.getValue(), option);
                this.enrichedValuesForTableSchemas.get(entry.getKey()).add(s);
            }
        }
    }

    /*
        pre-extract all values and vertices of enriched schemas
     */
    public void extractAllEnrichedValuesANDVids(HashMap<String, ArrayList<Integer>> schemaGraphMap, String option) {
        this.enrichedValuesForTableSchemas = new HashMap<>();
        this.enrichedVIDsForTableSchemas = new HashMap<>();
        for (Map.Entry<String, ArrayList<Integer>> entry : schemaGraphMap.entrySet()) {
            this.enrichedValuesForTableSchemas.put(entry.getKey(), new ArrayList<String>());
            this.enrichedVIDsForTableSchemas.put(entry.getKey(), new ArrayList<>());
            for (Integer vid : this.centerVIDs) {
                ImmutablePair<String, Integer> s = this.extractOnePathWithVID(vid, entry.getValue(), option);
                this.enrichedValuesForTableSchemas.get(entry.getKey()).add(s.left);
                this.enrichedVIDsForTableSchemas.get(entry.getKey()).add(s.right);
            }
        }
    }

    private ImmutablePair<String, Integer> extractOnePathWithVID(int vid, ArrayList<Integer> attribute, String option) {
        String value = "";
//        ArrayList<Edge> paths = new ArrayList<>();
        Vertex v = this.nodesMap.get(vid);
        for (int i = 0; i < attribute.size(); i++) {
            v = v.getNextVertex(attribute.get(i));
            if (v == null) {
                return new ImmutablePair<>("", null);
            }
            if (option.equals("all")) {
                value += v.getName() + " ";
            } else if (option.equals("one")) {
                value = v.getName();
            }
//            paths.add(v.getNextEdge(attribute.get(i)));
        }
        return new ImmutablePair<>(value, v.getVid());
    }

    private String extractOnePath(int vid, ArrayList<Integer> attribute, String option) {
        String value = "";
//        ArrayList<Edge> paths = new ArrayList<>();
        Vertex v = this.nodesMap.get(vid);
        for (int i = 0; i < attribute.size(); i++) {
            v = v.getNextVertex(attribute.get(i));
            if (v == null) {
                return "";
            }
            if (option.equals("all")) {
                value += v.getName() + " ";
            } else if (option.equals("one")) {
                value = v.getName();
            }
//            paths.add(v.getNextEdge(attribute.get(i)));
        }
        return value.trim();
    }

    // impute enriched schemas
    private void imputeOneAttributeOneTuple(int vid, int rid, String[] column, String attribute, String option) {
//        String value = this.extractOnePath(vid, attribute, option);
        String value = this.enrichedValuesForTableSchemas.get(attribute).get(this.centerVIDsMap.get(vid));
        column[rid] = value;
    }

    // impute enriched schemas
    private void imputeOneAttributeOneTupleTopK(ArrayList<ImmutablePair<Integer, Double>> HER, int rid, String[] column, String attribute, Similarity cos, Double[] queryEmbedd, String option) {
//        String value = this.extractOnePath(vid, attribute, option);
        // store embeddings of vertices
        ArrayList<Double []> vertexEmbeddings = new ArrayList<>();
        String value = null;
        double cos_max = -10;
        for (ImmutablePair<Integer, Double> pair : HER) {
            int vid = pair.left;
            if (!this.centerVIDsMap.containsKey(vid)) {
                continue;
            }
            String value_tail = this.enrichedValuesForTableSchemas.get(attribute).get(this.centerVIDsMap.get(vid));
            if (value_tail == null || value_tail.equals("")) {
                continue;
            }
            int vid_tail = this.enrichedVIDsForTableSchemas.get(attribute).get(this.centerVIDsMap.get(vid));
            Double[] embed_tail = this.embeddings.get(vid_tail);
            double _cos_ = cos.cosineSimilarity(queryEmbedd, embed_tail);
            if (_cos_ > cos_max) {
                cos_max = _cos_;
                value = value_tail;
            }
        }
        column[rid] = value;
    }

    // impute enriched schemas
    public void dataImputation(HashMap<Integer, ImmutablePair<Integer, Double>> HER, Table table, String option) {
        ArrayList<String> enrichedSchemas = table.getEnrichedSchemas();
        int tuplesNum = table.getTupleNums();
        for (int attrID = 0; attrID < enrichedSchemas.size(); attrID ++) {
            String schema = enrichedSchemas.get(attrID);
            String[] column = new String[tuplesNum];
            // iterate all tuples
            int tidCount = 0;
            ArrayList<Integer> path = table.getGraphPathLabels(schema);
            for (int tid = 0; tid < tuplesNum; tid++) {
                if (!HER.containsKey(tid)) {
                    continue;
                }
                int vid = HER.get(tid).getLeft();
                this.imputeOneAttributeOneTuple(vid, tidCount, column, schema, option);
                tidCount ++;
            }
            table.imputeColumn(column, attrID);
        }
    }

    // impute enriched schemas
    public void dataImputationTopK(HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER, Table table,
                                   Similarity cos, String option) {
        ArrayList<String> enrichedSchemas = table.getEnrichedSchemas();
        int tuplesNum = table.getTupleNums();
        for (int attrID = 0; attrID < enrichedSchemas.size(); attrID ++) {
            String schema = enrichedSchemas.get(attrID);
            String[] column = new String[tuplesNum];
            // iterate all tuples
            int tidCount = 0;
            ArrayList<Integer> path = table.getGraphPathLabels(schema);
            for (int tid = 0; tid < tuplesNum; tid++) {
                if (!HER.containsKey(tid)) {
                    continue;
                }
                ArrayList<ImmutablePair<Integer, Double>> her_one = HER.get(tid);
                Double[] queryEmbedd = table.getEmbeddings().get(tid);
                this.imputeOneAttributeOneTupleTopK(her_one, tidCount, column, schema, cos, queryEmbedd, option);
                tidCount ++;
            }
            table.imputeColumn(column, attrID);
        }
    }

//    public void printGraph(){
//        //I printed it like this. You can print it however you want though
//        for(Vertex v : nodes){
//            System.out.print("vertex name: "+ v.getName() + ": ");
//            for(Edge e : v.getEdges()){
//                System.out.print("destVertex: " + e.getDestVertex().getName() + " weight: " + e.getWeight() + " | ");
//            }
//            System.out.print("\n");
//        }
//    }
}
