package sics.seiois.mlsserver.biz.der.metanome.predicates;

public interface PartitionRefiner {
    public boolean satisfies(int line1, int lin2);

}
