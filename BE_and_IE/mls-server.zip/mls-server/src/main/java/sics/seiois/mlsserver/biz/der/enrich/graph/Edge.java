package sics.seiois.mlsserver.biz.der.enrich.graph;

import java.io.Serializable;

public class Edge implements Serializable {
    private static final long serialVersionUID = 4561123006068681007L;
    private int label;
    private Vertex destVertex;
    private Vertex srcVertex;
    private boolean ifUpdate;

    public Edge(Vertex src, Vertex dest, int w){
        this.srcVertex = src;
        this.destVertex = dest;
        this.label = w;
        this.ifUpdate = false;
    }

    public void setIfUpdate() {
        this.ifUpdate = true;
    }

    public boolean getIfUpdate() {
        return this.ifUpdate;
    }

    public Vertex getSrcVertex() {
        return this.srcVertex;
    }

    public int getLabel(){
        return this.label;
    }

    public Vertex getDestVertex(){
        return destVertex;
    }
}

