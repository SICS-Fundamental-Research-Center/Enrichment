package sics.seiois.mlsserver.biz.der.enrich.message;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class MessageEnrichInc implements Serializable {

    private static final long serialVersionUID = -2841743211393247070L;

    private ArrayList<HashMap<Integer, String>> affectedTuplesAllAttrs;

    public MessageEnrichInc(ArrayList<HashMap<Integer, String>> affectedTuplesAllAttrs) {
        this.affectedTuplesAllAttrs = affectedTuplesAllAttrs;
    }

    public ArrayList<HashMap<Integer, String>> getAffectedTuplesAllAttrs() {
        return this.affectedTuplesAllAttrs;
    }

}
