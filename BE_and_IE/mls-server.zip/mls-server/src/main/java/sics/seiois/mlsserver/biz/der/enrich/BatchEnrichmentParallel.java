package sics.seiois.mlsserver.biz.der.enrich;

import org.apache.commons.collections.ArrayStack;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.message.BroadcastEnrichObj;
import sics.seiois.mlsserver.biz.der.enrich.message.IMessageAggFunctionEnrich;
import sics.seiois.mlsserver.biz.der.enrich.message.MessageEnrich;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;
import sics.seiois.mlsserver.biz.der.mining.Message;
import sics.seiois.mlsserver.model.SparkContextConfig;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BatchEnrichmentParallel {
    private static final Logger logger = LoggerFactory.getLogger(BatchEnrichmentParallel.class);

    public final static int WORK_UNIT_TUPLE_NUM = 2000;
    public int NODE_NUM; // = 20;
    protected KGraph graph;
    protected Table table;
    protected Config config;
    protected Similarity jacc;
    protected Similarity cos;

    public BatchEnrichmentParallel(KGraph graph, Table table, Config config) {
        this.graph = graph;
        this.table = table;
        this.config = config;
        this.NODE_NUM = config.getNumOfWorks();
    }

    public void prepareAuxStructure() {
        ArrayList<ArrayList<Integer>> paths = config.getPathsBlocking();
        graph.serialize(paths, config.getPathLabelOption());
//        graph.extractAllEnrichedValues(config.getSchemasGraphMap(), config.getPathLabelOption());
        graph.extractAllEnrichedValuesANDVids(config.getSchemasGraphMap(), config.getPathLabelOption());
        graph.constructBlockingForIndex(Config.LIMITER);
        table.serialize(config.getSchemasBlocking());
        table.constructSerialsTokens(config.LIMITER);
        graph.loadEmbeddFile(config.getGraphEmbeddPath());
        table.loadEmbeddFile(config.getTableEmbeddPath());
    }

    public List<MessageEnrich> enrichmentParallel(String taskId, SparkSession spark, SparkContextConfig sparkContextConfig) {

        // split tables to a few blocks
        ArrayList<Table> tables = this.table.splitTableUniform(WORK_UNIT_TUPLE_NUM);
        ArrayList<ImmutablePair<Double, Table>> tablesInfo = new ArrayList<>();
        for (Table tab : tables) {
            double cost = tab.estimateHERBlockingCost(this.graph, this.config.getJaccThreshold());
            tablesInfo.add(new ImmutablePair<>(cost, tab));
        }
        tablesInfo.sort(new Comparator<ImmutablePair<Double, Table>>() {
                            @Override
                            public int compare(ImmutablePair<Double, Table> o1, ImmutablePair<Double, Table> o2) {
                                if (o1.getKey() < o2.getKey()) {
                                    return -1;
                                } else if (o1.getKey() > o2.getKey()) {
                                    return 1;
                                }
                                return 0;
                            }
                        }

        );
        ArrayList<ArrayList<Table>> block = new ArrayList<>();
//        ArrayList<Double> costs = new ArrayList<>();
        Double[] costs = new Double[NODE_NUM];
        for (int i = 0; i < NODE_NUM; i++) {
            ArrayList<Table> tabs = new ArrayList<>();
            block.add(tabs);
            costs[i] = 0.0;
        }
        for (ImmutablePair<Double, Table> pair : tablesInfo) {
            double minCost = costs[0];
            int sc = 0;
            for (int i = 1; i < costs.length; i++) {
                if (minCost > costs[i]) {
                    minCost = costs[i];
                    sc = i;
                }
            }
            block.get(sc).add(pair.getValue());
            costs[sc] += pair.getKey();
        }

//        KGraph graphLite = new KGraph(this.graph.getSerials(), this.graph.getCenterVIDs(), this.graph.getSerialsTokens(),
//                this.graph.getCenterVIDsMap(), this.graph.getInvertedIndex(), this.graph.getEmbeddings(), this.graph.getEdgeNum(),
//                this.graph.getEnrichedValuesForTableSchemas());

        KGraph graphLite = new KGraph(null, this.graph.getCenterVIDs(), this.graph.getSerialsTokens(),
                this.graph.getCenterVIDsMap(), this.graph.getInvertedIndex(), this.graph.getEmbeddings(), this.graph.getEdgeNum(),
                this.graph.getEnrichedValuesForTableSchemas(), this.graph.getEnrichedVIDsForTableSchemas());

        // parallel batch enrichment
        ArrayList<WorkUnitBE> workUnitsBE = new ArrayList<>();
        for (int i = 0; i < NODE_NUM; i++) {
            // in case a block has no tables
            if (block.get(i).size() <= 0) {
                continue;
            }

            WorkUnitBE workUnitBE = new WorkUnitBE(new KGraph(), block.get(i), this.config);
            workUnitsBE.add(workUnitBE);
        }
//        List<MessageEnrich> messages = this.run(workUnitsBE, taskId, spark, sparkContextConfig, graphLite);
        List<MessageEnrich> messages = this.runLocal(workUnitsBE, graphLite);
        logger.info("Finish batch enrichment");
        return messages;
    }

    public List<MessageEnrich> run(ArrayList<WorkUnitBE> workUnits, String taskId, SparkSession spark,
                                   SparkContextConfig sparkContextConfig, KGraph graph) {
        JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());

        BroadcastEnrichObj broadcastEnrichObj = new BroadcastEnrichObj(graph);
        Broadcast<BroadcastEnrichObj> scInput = sc.broadcast(broadcastEnrichObj);

        List<MessageEnrich> messages = sc.parallelize(workUnits, workUnits.size()).map(task -> {

            BroadcastEnrichObj bEnrichObj = scInput.getValue();
            KGraph graphLite = bEnrichObj.getGraph();
            task.setGraph(graphLite);
            BatchEnrichment batchEnrichment = task.getBatchEnrichment();
            List<MessageEnrich> partialMessage = new ArrayList<>();
            for (Table table : task.getTables()) {
                batchEnrichment.setTable(table);
                batchEnrichment.enrichment();
                HashMap<String, String[]> enrichedB = new HashMap<>();
                for (String attribute : batchEnrichment.getConfig().getEnrichedSchemas()) {
                    enrichedB.put(attribute, batchEnrichment.getTable().getColumn(attribute));
                }
                MessageEnrich message = new MessageEnrich(batchEnrichment.getTable().getTidBegin(),
                        batchEnrichment.getTable().getTidEnd(), batchEnrichment.getHER());
                partialMessage.add(message);
            }
            return partialMessage;
        }).aggregate(null, new IMessageAggFunctionEnrich(), new IMessageAggFunctionEnrich());
        return messages;
    }


    // for test parallel
    public List<MessageEnrich> runLocal(ArrayList<WorkUnitBE> workUnits, KGraph graph) {

        int K = 3;
        List<MessageEnrich> messages = new ArrayList<>();
        for (WorkUnitBE task : workUnits) {

            task.setGraph(graph);
            BatchEnrichment batchEnrichment = task.getBatchEnrichment();
            List<MessageEnrich> partialMessage = new ArrayList<>();
            for (Table table : task.getTables()) {
                batchEnrichment.setTable(table);
                batchEnrichment.enrichmentTopK(K);
                HashMap<String, String[]> enrichedB = new HashMap<>();
                for (String attribute : batchEnrichment.getConfig().getEnrichedSchemas()) {
                    enrichedB.put(attribute, batchEnrichment.getTable().getColumn(attribute));
                }
//                MessageEnrich message = new MessageEnrich(batchEnrichment.getTable().getTidBegin(),
//                        batchEnrichment.getTable().getTidEnd(), batchEnrichment.getHER());
                MessageEnrich message = new MessageEnrich(batchEnrichment.getTable().getTidBegin(),
                        batchEnrichment.getTable().getTidEnd(), "", batchEnrichment.getHER_topK());
                partialMessage.add(message);
            }
            for (MessageEnrich m : partialMessage) {
                messages.add(m);
            }
        }
        return messages;
    }


    // Parallel batch enrichment in a single machine
    public List<MessageEnrich> enrichmentParallelThread(int K) {

        // split tables to a few blocks
        ArrayList<Table> tables = this.table.splitTableUniform(WORK_UNIT_TUPLE_NUM);
        ArrayList<ImmutablePair<Double, Table>> tablesInfo = new ArrayList<>();
        for (Table tab : tables) {
            double cost = tab.estimateHERBlockingCost(this.graph, this.config.getJaccThreshold());
            tablesInfo.add(new ImmutablePair<>(cost, tab));
        }
        tablesInfo.sort(new Comparator<ImmutablePair<Double, Table>>() {
                            @Override
                            public int compare(ImmutablePair<Double, Table> o1, ImmutablePair<Double, Table> o2) {
                                if (o1.getKey() < o2.getKey()) {
                                    return -1;
                                } else if (o1.getKey() > o2.getKey()) {
                                    return 1;
                                }
                                return 0;
                            }
                        }

        );
        ArrayList<ArrayList<Table>> block = new ArrayList<>();
//        ArrayList<Double> costs = new ArrayList<>();
        Double[] costs = new Double[NODE_NUM];
        for (int i = 0; i < NODE_NUM; i++) {
            ArrayList<Table> tabs = new ArrayList<>();
            block.add(tabs);
            costs[i] = 0.0;
        }
        for (ImmutablePair<Double, Table> pair : tablesInfo) {
            double minCost = costs[0];
            int sc = 0;
            for (int i = 1; i < costs.length; i++) {
                if (minCost > costs[i]) {
                    minCost = costs[i];
                    sc = i;
                }
            }
            block.get(sc).add(pair.getValue());
            costs[sc] += pair.getKey();
        }

//        KGraph graphLite = new KGraph(this.graph.getSerials(), this.graph.getCenterVIDs(), this.graph.getSerialsTokens(),
//                this.graph.getCenterVIDsMap(), this.graph.getInvertedIndex(), this.graph.getEmbeddings(), this.graph.getEdgeNum(),
//                this.graph.getEnrichedValuesForTableSchemas());

        KGraph graphLite = new KGraph(null, this.graph.getCenterVIDs(), this.graph.getSerialsTokens(),
                this.graph.getCenterVIDsMap(), this.graph.getInvertedIndex(), this.graph.getEmbeddings(), this.graph.getEdgeNum(),
                this.graph.getEnrichedValuesForTableSchemas(), this.graph.getEnrichedVIDsForTableSchemas());

        // parallel batch enrichment
        ArrayList<MessageEnrich> messageEnriches = new ArrayList<>();
        ArrayList<WorkUnitBEThread> workUnitsBE = new ArrayList<>();
        for (int i = 0; i < NODE_NUM; i++) {
            // in case a block has no tables
            if (block.get(i).size() <= 0) {
                continue;
            }
            WorkUnitBEThread workUnitBE = new WorkUnitBEThread(this.graph, block.get(i), this.config, K, messageEnriches);
            workUnitsBE.add(workUnitBE);
        }
//        List<MessageEnrich> messages = this.run(workUnitsBE, taskId, spark, sparkContextConfig, graphLite);
//        List<MessageEnrich> messages = this.runLocal(workUnitsBE, graphLite);
        // multi-thread
        ExecutorService pool = Executors.newFixedThreadPool(NODE_NUM);
        for (WorkUnitBEThread workUnitBEThread: workUnitsBE) {
            pool.execute(workUnitBEThread);
        }

        pool.shutdown();
        try {
            while (true) {
                if (pool.isTerminated()) {
                    break;
                }
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            logger.error("", e);
        }
        logger.info("Finish batch enrichment");
        return messageEnriches;
    }

}