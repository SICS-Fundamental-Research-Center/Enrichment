package sics.seiois.mlsserver.biz.der.enrich;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.KryoSerializable;
import javafx.scene.control.Tab;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;

import java.util.ArrayList;

public class WorkUnitBE extends Thread implements KryoSerializable {

    private BatchEnrichment batchEnrichment;
    private ArrayList<Table> tables;


    public WorkUnitBE(KGraph graph, ArrayList<Table> tables, Config config) {
        super();
        // first consider the first table
        this.batchEnrichment = new BatchEnrichment(graph, tables.get(0), config);
        this.tables = tables;
    }

    public BatchEnrichment getBatchEnrichment() {
        return this.batchEnrichment;
    }

    public void setGraph(KGraph graph) {
        this.batchEnrichment.setGraph(graph);
    }

    public ArrayList<Table> getTables() {
        return this.tables;
    }

    @Override
    public void write(Kryo kryo, Output output) {
        kryo.writeObject(output, batchEnrichment);
        kryo.writeObject(output, tables);
    }

    @Override
    public void read(Kryo kryo, Input input) {
        this.batchEnrichment = kryo.readObject(input, BatchEnrichment.class);
        this.tables = kryo.readObject(input, ArrayList.class);
    }
}
