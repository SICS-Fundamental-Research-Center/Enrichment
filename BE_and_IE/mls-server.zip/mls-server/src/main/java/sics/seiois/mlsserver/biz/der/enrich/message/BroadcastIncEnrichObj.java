package sics.seiois.mlsserver.biz.der.enrich.message;

import org.apache.commons.lang3.tuple.ImmutablePair;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;

import java.io.Serializable;
import java.util.HashMap;

public class BroadcastIncEnrichObj implements Serializable {
    private static final long serialVersionUID = -49514321048039007L;

    private Table table;
//    private HashMap<Integer, ImmutablePair<Integer, Double>> HER;
//    private HashMap<Integer, ImmutablePair<Integer, Double>> HERInverse;

    public BroadcastIncEnrichObj(Table table) {
        this.table = table;
//        this.HER = HER;
//        this.HERInverse = HERInverse;
    }

    public Table getTable() {
        return this.table;
    }

//    public HashMap<Integer, ImmutablePair<Integer, Double>> getHER() {
//        return this.HER;
//    }
//
//    public HashMap<Integer, ImmutablePair<Integer, Double>> getHERInverse() {
//        return this.HERInverse;
//    }

}
