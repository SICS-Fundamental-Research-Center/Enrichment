package sics.seiois.mlsserver.biz.der.enrich;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.hadoop.fs.FSDataInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class Config implements Serializable{

    private static final long serialVersionUID = 40392774392568147L;

    private static final Logger logger = LoggerFactory.getLogger(Config.class);

    public static final String LIMITER = " ";
    // Table
    private String tableName;
    private String tablePath;
    private ArrayList<String> schemasBlocking;
    private ArrayList<String> enrichedSchemas;
    private String tableEmbeddPath;
    // Table to Graph
    private String graphFile;
    private String graphEmbeddPath;
    private HashMap<String, ArrayList<Integer>> schemasGraphMap;
    // option: "all" -> load all labels of passing vertices
    // "one" -> only load the label of the last vertex in the given path
    String pathLabelOption;
    private int pathhLenK;
    private double sampleRatio;
    String enrichedTablePath;

    String ifIncEnrich;
    String updatedEnrichedTablePath;
    private int numOfWorks;

    private int ifHEROPT; // 1 means using HER blocking, 0 means using brute force HER
    private int ifIncIE; // 1 means using incremental enrichment for graph updates, 0 means using batch enrichment for graph updates

    private double sampleRatioTableBE;
    private double sampleRatioGraphBE;
    private double sampleRatioTableUpdateIE;

    public double getSampleRatioTableUpdateIE() {
        return this.sampleRatioTableUpdateIE;
    }

    public int getIfIncIE() {
        return this.ifIncIE;
    }

    // transform schemas of blocking to paths in KG
    public ArrayList<ArrayList<Integer>> getPathsBlocking() {
        ArrayList<ArrayList<Integer>> paths = new ArrayList<>();
        for (String schema : this.schemasBlocking) {
            paths.add(this.schemasGraphMap.get(schema));
        }
        return paths;
    }

    public int getNumOfWorks() {
        return this.numOfWorks;
    }

    public double getSampleRatioTableBE() {
        return this.sampleRatioTableBE;
    }

    public double getSampleRatioGraphBE() {
        return this.sampleRatioGraphBE;
    }

    public int getIfHEROPT() {
        return this.ifHEROPT;
    }

    // Jaccard threshold
    private double jaccThreshold;

    public double getSampleRatio(){
        return this.sampleRatio;
    }

    public int getPathhLenK() {
        return this.pathhLenK;
    }

    public String getTableName() {
        return this.tableName;
    }

    public String getTablePath() {
        return this.tablePath;
    }

    public ArrayList<String> getSchemasBlocking() {
        return this.schemasBlocking;
    }

    public ArrayList<String> getEnrichedSchemas() {
        return this.enrichedSchemas;
    }

    public String getGraphFile() {
        return this.graphFile;
    }

    public HashMap<String, ArrayList<Integer>> getSchemasGraphMap() {
        return this.schemasGraphMap;
    }

    public double getJaccThreshold() {
        return this.jaccThreshold;
    }

    public String getPathLabelOption() {
        return this.pathLabelOption;
    }

    public String getTableEmbeddPath() {
        return this.tableEmbeddPath;
    }

    public String getGraphEmbeddPath() {
        return this.graphEmbeddPath;
    }

    public String getEnrichedTablePath() {
        return this.enrichedTablePath;
    }

    public String getUpdatedEnrichedTablePath() {
        return this.updatedEnrichedTablePath;
    }

    public boolean ifIncEnrich() {
        if (this.ifIncEnrich.equals("yes")) {
            return true;
        } else {
            return false;
        }
    }

    public Config (String config_file) {
        /*
            Each line is
         */
        String jsonStr = "";
        this.schemasBlocking = new ArrayList<String>();
        this.enrichedSchemas = new ArrayList<String>();
        this.schemasGraphMap = new HashMap<>();
        try {
            File file = new File(config_file);
            FileReader fr = new FileReader(file);
            Reader reader = new InputStreamReader(new FileInputStream(file), "utf-8");
            int ch = 0;
            StringBuffer sb  = new StringBuffer();
            while((ch = reader.read()) != -1) {
                sb.append((char)ch);
            }
            fr.close();
            reader.close();
            jsonStr = sb.toString();

            logger.info(jsonStr);

            // transform to json
            JSONObject jobj = JSON.parseObject(jsonStr);
            JSONArray schemasBlockingArr = jobj.getJSONArray("schemasBlocking");
            JSONArray enrichedSchemasArr = jobj.getJSONArray("enrichedSchemas");
            JSONObject schemasGraphMapObj = jobj.getJSONObject("schemasGraphMap");
            this.tableName = jobj.getString("tableName");
            this.tablePath = jobj.getString("tablePath");
            this.jaccThreshold = Double.parseDouble(jobj.getString("jaccThreshold"));
            this.pathLabelOption = jobj.getString("pathLabelOption");
            this.tableEmbeddPath = jobj.getString("tableEmbeddPath");
            this.graphEmbeddPath = jobj.getString("graphEmbeddPath");
            this.enrichedTablePath = jobj.getString("enrichedTablePath");
            this.updatedEnrichedTablePath = jobj.getString("updatedEnrichedTablePath");
            this.graphFile = jobj.getString("graphPath");
            this.pathhLenK = jobj.getInteger("pathLenK");
            this.ifHEROPT = jobj.getInteger("ifHEROPT");
            this.ifIncIE = jobj.getInteger("ifIncIE");
            this.numOfWorks = jobj.getInteger("numOfWorkers");
            this.sampleRatio = jobj.getDouble("sampleRatio");
            this.sampleRatioTableBE = jobj.getDouble("sampleRatioTableBE");
            this.sampleRatioGraphBE = jobj.getDouble("sampleRatioGraphBE");
            this.sampleRatioTableUpdateIE = jobj.getDouble("sampleRatioTableUpdateIE");
            this.ifIncEnrich = jobj.getString("ifIncEnrich");
            for (int i = 0; i <schemasBlockingArr.size(); i++) {
                this.schemasBlocking.add((String)schemasBlockingArr.get(i));
            }
            for (int i = 0; i < enrichedSchemasArr.size(); i++) {
                this.enrichedSchemas.add((String)enrichedSchemasArr.get(i));
            }
            for (Map.Entry<String, Object> entry : schemasGraphMapObj.entrySet()) {
                String[] v = entry.getValue().toString().split("_");
                ArrayList<Integer> v_ = new ArrayList<>(); // (Arrays.asList(v));
                for (String s : v) {
                    v_.add(Integer.parseInt(s.trim()));
                }
                this.schemasGraphMap.put(entry.getKey(), v_);

            }

        } catch (IOException e) {
            e.printStackTrace();

        }
    }


    public Config (String config_file, FileSystem hdfs) {
        /*
            Each line is
         */
        String jsonStr = "";
        this.schemasBlocking = new ArrayList<String>();
        this.enrichedSchemas = new ArrayList<String>();
        this.schemasGraphMap = new HashMap<>();
        try {
//            File file = new File(config_file);
//            FileReader fr = new FileReader(file);
//            Reader reader = new InputStreamReader(new FileInputStream(file), "utf-8");
//            int ch = 0;
//            StringBuffer sb  = new StringBuffer();
//            while((ch = reader.read()) != -1) {
//                sb.append((char)ch);
//            }
//            fr.close();
//            reader.close();

            FSDataInputStream inputTxt = hdfs.open(new Path(config_file));
            BufferedInputStream bis = new BufferedInputStream(inputTxt);
            InputStreamReader sReader = new InputStreamReader(bis, "UTF-8");
            BufferedReader bReader = new BufferedReader(sReader);
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while((ch = bReader.read()) != -1) {
                sb.append((char)ch);
            }
            bReader.close();

            jsonStr = sb.toString();

            logger.info(jsonStr);

            // transform to json
            JSONObject jobj = JSON.parseObject(jsonStr);
            JSONArray schemasBlockingArr = jobj.getJSONArray("schemasBlocking");
            JSONArray enrichedSchemasArr = jobj.getJSONArray("enrichedSchemas");
            JSONObject schemasGraphMapObj = jobj.getJSONObject("schemasGraphMap");
            this.tableName = jobj.getString("tableName");
            this.tablePath = jobj.getString("tablePath");
            this.jaccThreshold = Double.parseDouble(jobj.getString("jaccThreshold"));
            this.pathLabelOption = jobj.getString("pathLabelOption");
            this.tableEmbeddPath = jobj.getString("tableEmbeddPath");
            this.graphEmbeddPath = jobj.getString("graphEmbeddPath");
            this.enrichedTablePath = jobj.getString("enrichedTablePath");
            this.updatedEnrichedTablePath = jobj.getString("updatedEnrichedTablePath");
            this.graphFile = jobj.getString("graphPath");
            this.pathhLenK = jobj.getInteger("pathLenK");
            this.ifHEROPT = jobj.getInteger("ifHEROPT");
            this.ifIncIE = jobj.getInteger("ifIncIE");
            this.numOfWorks = jobj.getInteger("numOfWorkers");
            this.sampleRatio = jobj.getDouble("sampleRatio");
            this.sampleRatioTableBE = jobj.getDouble("sampleRatioTableBE");
            this.sampleRatioGraphBE = jobj.getDouble("sampleRatioGraphBE");
            this.sampleRatioTableUpdateIE = jobj.getDouble("sampleRatioTableUpdateIE");
            this.ifIncEnrich = jobj.getString("ifIncEnrich");
            for (int i = 0; i <schemasBlockingArr.size(); i++) {
                this.schemasBlocking.add((String)schemasBlockingArr.get(i));
            }
            for (int i = 0; i < enrichedSchemasArr.size(); i++) {
                this.enrichedSchemas.add((String)enrichedSchemasArr.get(i));
            }
            for (Map.Entry<String, Object> entry : schemasGraphMapObj.entrySet()) {
                String[] v = entry.getValue().toString().split("_");
                ArrayList<Integer> v_ = new ArrayList<>(); // (Arrays.asList(v));
                for (String s : v) {
                    v_.add(Integer.parseInt(s.trim()));
                }
                this.schemasGraphMap.put(entry.getKey(), v_);

            }

        } catch (IOException e) {
            e.printStackTrace();

        }
    }

}
