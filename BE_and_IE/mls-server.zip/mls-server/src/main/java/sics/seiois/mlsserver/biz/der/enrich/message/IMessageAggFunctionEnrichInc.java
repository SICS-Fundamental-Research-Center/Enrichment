package sics.seiois.mlsserver.biz.der.enrich.message;

import org.apache.spark.api.java.function.Function2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class IMessageAggFunctionEnrichInc implements Function2<List<MessageEnrichInc>, List<MessageEnrichInc>, List<MessageEnrichInc>> {
    private static Logger log = LoggerFactory.getLogger(IMessageAggFunctionEnrichInc.class);

    @Override
    public List<MessageEnrichInc> call(List<MessageEnrichInc> mg_1, List<MessageEnrichInc> mg_2) {
        if (mg_1 == null) {
            return mg_2;
        }

        if (mg_2 == null) {
            return mg_1;
        }

        List<MessageEnrichInc> allmg = new ArrayList<>();
        allmg.addAll(mg_1);
        allmg.addAll(mg_2);
        return allmg;

    }
}
