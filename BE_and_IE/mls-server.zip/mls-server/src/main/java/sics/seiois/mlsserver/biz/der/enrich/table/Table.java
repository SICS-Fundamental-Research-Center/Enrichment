package sics.seiois.mlsserver.biz.der.enrich.table;

import de.metanome.algorithm_integration.configuration.ConfigurationSettingFileInput;
import de.metanome.algorithm_integration.input.InputIterationException;
import de.metanome.algorithm_integration.input.RelationalInput;
import de.metanome.backend.input.file.FileIterator;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.json4s.FileInput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sics.seiois.mlsserver.biz.der.enrich.Config;
import sics.seiois.mlsserver.biz.der.enrich.Similarity;
import sics.seiois.mlsserver.biz.der.enrich.Utils;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashSet;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.io.*;

public class Table implements Serializable {

    private static Logger log = LoggerFactory.getLogger(Table.class);

    private int numOfAttrs;
    private ArrayList<String> basicSchemas;
    private ArrayList<String> enrichedSchemas;

    private HashMap<String, ArrayList<Integer>> schemasGraphMap;

    private HashMap<String, String[]> columnsMap;

    private ArrayList<Double[]> embeddings;
    private int tidBegin;
    private int tidEnd; // exclusive

    private String[] serials;
    private ArrayList<String[]> serialsTokens;
    private HashMap<String, ArrayList<Integer>> invertedIndex;
    private HashMap<String, HashMap<Integer, ArrayList<Integer>>> invertedIndexLength; // the second key is sizes of token sets
    private HashMap<String, Integer> tokenFreqs;

    public HashMap<String, ArrayList<Integer>> getSchemasGraphMap() {
        return this.schemasGraphMap;
    }

    // Lite version of Table
//    public Table(ArrayList<String> basicSchemas, ArrayList<String> enrichedSchemas,
//                 HashMap<String, ArrayList<Integer>> schemasGraphMap, ArrayList<Double[]> embeddings,
//                 int tidBegin, int tidEnd, String[] serials, ArrayList<String[]> serialsTokens,
//                 HashMap<String, ArrayList<Integer>> invertedIndex) {
//        this.basicSchemas = basicSchemas;
//        this.enrichedSchemas = enrichedSchemas;
//        this.schemasGraphMap = schemasGraphMap;
//        this.columnsMap = null;
//        this.embeddings = embeddings;
//        this.tidBegin = tidBegin;
//        this.tidEnd = tidEnd;
//        this.serials = serials;
//        this.serialsTokens = serialsTokens;
//        this.invertedIndex = invertedIndex;
//    }

    public Table(ArrayList<String> basicSchemas, ArrayList<String> enrichedSchemas,
                 HashMap<String, ArrayList<Integer>> schemasGraphMap, ArrayList<Double[]> embeddings,
                 int tidBegin, int tidEnd, String[] serials, ArrayList<String[]> serialsTokens,
                 HashMap<String, HashMap<Integer, ArrayList<Integer>>> invertedIndex,
                 HashMap<String, Integer> tokenFreqs) {
        this.basicSchemas = basicSchemas;
        this.enrichedSchemas = enrichedSchemas;
        this.schemasGraphMap = schemasGraphMap;
        this.columnsMap = null;
        this.embeddings = embeddings;
        this.tidBegin = tidBegin;
        this.tidEnd = tidEnd;
        this.serials = serials;
        this.serialsTokens = serialsTokens;
//        this.invertedIndex = invertedIndex;
        this.invertedIndexLength = invertedIndex;
        this.tokenFreqs = tokenFreqs;
    }

    public Table() {

    }

    public HashMap<String, HashMap<Integer, ArrayList<Integer>>> getInvertedIndexLength() {
        return this.invertedIndexLength;
    }

    public HashMap<String, Integer> getTokenFreqs() {
        return this.tokenFreqs;
    }

    public int getSerialNum() {
        return this.serials.length;
    }
    /*
        save enriched table to disk
     */
    public void saveEnrichedTable(String outputFile) {
        try {
            FileWriter fileWriter = new FileWriter(outputFile);
            String schemas = "";
            for (int i = 0; i < this.basicSchemas.size(); i++) {
                schemas += this.basicSchemas.get(i) + ",";
            }
            for (int i = 0; i < this.enrichedSchemas.size(); i++) {
                schemas += this.enrichedSchemas.get(i) + ",";
            }
            schemas = schemas.substring(0, schemas.length() - 1);
            fileWriter.write(schemas);
            fileWriter.write("\r\n");
            String record = "";
            for (int t = 0; t < this.tidEnd - this.tidBegin; t++) {
                record = "";
                for (int i = 0; i < this.basicSchemas.size(); i++) {
                    String attr = this.basicSchemas.get(i);
                    record += this.columnsMap.get(attr)[t] + ",";
                }
                for (int i = 0; i < this.enrichedSchemas.size(); i++) {
                    String attr = this.enrichedSchemas.get(i);
                    record += this.columnsMap.get(attr)[t] + ",";
                }
                record = record.substring(0, record.length() - 1);
                fileWriter.write(record);
                fileWriter.write("\r\n");
            }
            fileWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Table> splitTableUniform(int tupleNumEach) {
        int tupleNumTotal = this.tidEnd - this.tidBegin; // this.columnsMap.get(this.basicSchemas.get(0)).length;
        ArrayList<ImmutablePair<Integer, Integer>> tidIntervels = new ArrayList<>();
        int sc = 0;
        for (;sc < tupleNumTotal; sc += tupleNumEach) {
            int bb = sc;
            int ee = sc + tupleNumEach;
            if (ee >= tupleNumTotal) {
                ee = tupleNumTotal;
            }
            tidIntervels.add(new ImmutablePair<>(bb, ee));
        }
        // deal with the last one
//        tidIntervels.add(new ImmutablePair<>(sc, tupleNumTotal));
        // split table
        ArrayList<Table> tables = new ArrayList<>();
        for (int i = 0; i < tidIntervels.size(); i++) {
            int tidBeginSub = tidIntervels.get(i).getLeft();
            int tidEndSub = tidIntervels.get(i).getRight();
            // partition columnsMap
            HashMap<String, String[]> columnsMapSub = new HashMap<>();
            // do not need to broadcast the whole datasets
//            for (Map.Entry<String, String[]> entry: this.columnsMap.entrySet()) {
//                String[] subCol = new String[tidEndSub - tidBeginSub];
//                int z = 0;
//                for (int tid = tidBeginSub; tid < tidEndSub; tid++) {
//                    subCol[z++] = entry.getValue()[tid];
//                }
//                columnsMapSub.put(entry.getKey(), subCol);
//            }
            // partition embeddings
            ArrayList<Double[]> embeddingsSub = new ArrayList<>();
            for (int tid = tidBeginSub; tid < tidEndSub; tid++) {
                embeddingsSub.add(this.embeddings.get(tid));
            }
            // partition serials
            String[] serialsSub = new String[tidEndSub - tidBeginSub];
            int z = 0;
            for (int tid = tidBeginSub; tid < tidEndSub; tid++) {
                serialsSub[z++] = this.serials[tid];
            }
            // partition serialsTokens
            ArrayList<String[]> serialsTokensSub = new ArrayList<>();
            z = 0;
            for (int tid = tidBeginSub; tid < tidEndSub; tid++) {
                serialsTokensSub.add(this.serialsTokens.get(tid));
            }
            // do not consider inverted index for BE
            Table tab = new Table(this.basicSchemas, this.enrichedSchemas, this.schemasGraphMap, columnsMapSub,
                    embeddingsSub, tidBeginSub, tidEndSub, serialsSub, serialsTokensSub, null);
            tables.add(tab);
        }
        return tables;
    }

    public Table(ArrayList<String> basicSchemas, ArrayList<String> enrichedSchemas,
                 HashMap<String, ArrayList<Integer>> schemasGraphMap,
                 HashMap<String, String[]> columnsMap, ArrayList<Double[]> embeddings,
                 int tidBegin, int tidEnd, String[] serials, ArrayList<String[]> serialsTokens,
                 HashMap<String, ArrayList<Integer>> invertedIndex) {
        this.basicSchemas = basicSchemas;
        this.enrichedSchemas = enrichedSchemas;
        this.schemasGraphMap = schemasGraphMap;
        this.columnsMap = columnsMap;
        this.embeddings = embeddings;
        this.tidBegin = tidBegin;
        this.tidEnd = tidEnd;
        this.serials = serials;
        this.serialsTokens = serialsTokens;
        this.invertedIndex = invertedIndex;
    }

    public void loadEmbeddFile(String tableEmbeddFile) {
        this.embeddings = new ArrayList<>();
        if (tableEmbeddFile.equals("")) {
            int len = this.serials.length;
            for (int i = 0; i < len; i ++) {
                Double[] m = new Double[20];
                for (int z = 0; z < m.length; z++) {
                    m[z] = 1.0;
                }
                this.embeddings.add(m);
            }
            return;
        }
        File file = new File(tableEmbeddFile);
        try {
            // use string to store float
//            FileReader fr = new FileReader(file);
//            BufferedReader br = new BufferedReader(fr);
//            String line;
//            while ((line = br.readLine()) != null) {
//                String[] embeddStr = line.split("");
//                Double[] embed = new Double[embeddStr.length];
//                for (int z = 0; z < embeddStr.length; z++) {
//                    embed[z] = Double.parseDouble(embeddStr[z]);
//                }
//                this.embeddings.add(embed);
//            }

            // load binary file
            FileInputStream inputStream = new FileInputStream(tableEmbeddFile);
            DataInputStream dis = new DataInputStream(inputStream);
            int tupleNum = (int)dis.readFloat();
            int embedDim = (int)dis.readFloat();
//            long count = dis.available();
//            System.out.printf("count is %d, %d, %s\n", tupleNum, embedDim, Long.toString(count));
//            byte[] bbs = new byte[(int)count];
//            int bytes = dis.read(bbs);
//            float[] floats = new float[(int)(bbs.length / 4)];
//            ByteBuffer buffer = ByteBuffer.wrap(bbs);
//            buffer.order(ByteOrder.BIG_ENDIAN);
//            for (int i = 0; i < floats.length; i++) {
//                floats[i] = buffer.getFloat();
//            }
//            for (int z = 0; z < tupleNum; z++) {
//                Double[] embed = new Double[embedDim];
//                for (int z_ = 0; z_ < embedDim; z_++) {
//                    embed[z_] = (double) floats[z * embedDim + z_];
//                }
//                this.embeddings.add(embed);
//            }

            // a slow version
            int partition = 500000;
            for (int rid = 0; rid < tupleNum; rid+=partition) {
                System.out.println("--------------------------");
                int interval = partition;
                if ((rid + partition) >= tupleNum) {
                    interval = tupleNum - rid;
                }
                byte[] bbs_ = new byte[embedDim * 4 * interval];
                int bytes_ = dis.read(bbs_);
                ByteBuffer buffer_ = ByteBuffer.wrap(bbs_);
                buffer_.order(ByteOrder.BIG_ENDIAN);
                for (int ttid = 0; ttid < interval; ttid++) {
                    Double[] embed = new Double[embedDim];
                    for (int z_ = 0; z_ < embedDim; z_++) {
                        embed[z_] = (double) buffer_.getFloat();
                    }
                    this.embeddings.add(embed);
                }
            }
            System.out.println("========================");

//            while (dis.available() > 0) {
//                for (int z = 0; z < tupleNum; z++) {
//                    Double[] embed = new Double[embedDim];
//                    for (int z_ = 0; z_ < embedDim; z_++) {
//                        embed[z_] = (double) dis.readFloat();
//                    }
//                    this.embeddings.add(embed);
//                }
//            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // for parallel version (load from hdfs)
    public Table(Config config) {
        this.basicSchemas = new ArrayList<String>();
        this.enrichedSchemas = config.getEnrichedSchemas(); //new ArrayList<String>();
        this.schemasGraphMap = config.getSchemasGraphMap(); //new HashMap<String, ArrayList<String>>();
        this.columnsMap = new HashMap<String, String[]>();
    }

    public void loadTableFromHDFS(String tableName, String tablePath, double sampleRatioTableBE) {
        try {
            FileSystem hdfs = FileSystem.get(new Configuration());
            org.apache.hadoop.fs.Path pathD = new Path(tablePath);
            FSDataInputStream fsin = hdfs.open(pathD);
            BufferedReader br = new BufferedReader(new InputStreamReader(fsin));
            RelationalInput relation = new FileIterator(tableName, br,
                    new ConfigurationSettingFileInput(tablePath));

            for (int i = 0; i < relation.numberOfColumns(); i++) {
                this.basicSchemas.add(relation.columnNames().get(i));
            }
            List<List<String>> lines = new ArrayList<>();
            while (relation.hasNext()) {
                List<String> row = relation.next();
                lines.add(row);
            }
            int tupleNum_ = lines.size();
            int sampleNum_ = (int)(tupleNum_ * sampleRatioTableBE);
            for (int attrID = 0; attrID < this.basicSchemas.size(); attrID++) {
                String attrName = this.basicSchemas.get(attrID);
//                String[] col_ = new String[lines.size()];
                String[] col_ = new String[sampleNum_];
                for (int z = 0; z < lines.size(); z++) {
                    if (z >= sampleNum_) {
                        break;
                    }
                    col_[z] = lines.get(z).get(attrID);

                }
                this.columnsMap.put(attrName, col_);
            }
            this.tidBegin = 0;
            this.tidEnd = this.columnsMap.get(this.basicSchemas.get(0)).length;

        } catch (Exception e) {
            log.info("load table error ", e);
            throw new RuntimeException(e);
        }

    }

    public void loadTable(String tableName, String tablePath, double sampleRatioTableBE) {
        try {
            //FileSystem hdfs = FileSystem.get(new Configuration());
            //org.apache.hadoop.fs.Path pathD = new Path(tablePath);
            //FSDataInputStream fsin = hdfs.open(pathD);
            //BufferedReader br = new BufferedReader(new InputStreamReader(fsin));

            FileReader fileReader = new FileReader(tablePath);
            RelationalInput relation = new FileIterator(tableName, fileReader,
                    new ConfigurationSettingFileInput(tablePath));

            for (int i = 0; i < relation.numberOfColumns(); i++) {
                this.basicSchemas.add(relation.columnNames().get(i));
            }
            List<List<String>> lines = new ArrayList<>();
            while (relation.hasNext()) {
                List<String> row = relation.next();
                lines.add(row);
            }
            int tupleNum_ = lines.size();
            int sampleNum_ = (int)(tupleNum_ * sampleRatioTableBE);
            for (int attrID = 0; attrID < this.basicSchemas.size(); attrID++) {
                String attrName = this.basicSchemas.get(attrID);
//                String[] col_ = new String[lines.size()];
                String[] col_ = new String[sampleNum_];
                for (int z = 0; z < lines.size(); z++) {
                    if (z >= sampleNum_) {
                        break;
                    }
                    col_[z] = lines.get(z).get(attrID);

                }
                this.columnsMap.put(attrName, col_);
            }
            this.tidBegin = 0;
            this.tidEnd = this.columnsMap.get(this.basicSchemas.get(0)).length;

        } catch (Exception e) {
            log.info("load table error ", e);
            throw new RuntimeException(e);
        }

    }


    public Table(String tableName, String tablePath, Config config) {
        this.basicSchemas = new ArrayList<String>();
        this.enrichedSchemas = config.getEnrichedSchemas(); //new ArrayList<String>();
        this.schemasGraphMap = config.getSchemasGraphMap(); //new HashMap<String, ArrayList<String>>();
        this.columnsMap = new HashMap<String, String[]>();
        try {
            // load csv from local disk
            FileReader fileReader = new FileReader(tablePath);
            RelationalInput relation = new FileIterator(tableName, fileReader,
                    new ConfigurationSettingFileInput(tablePath));

            for (int i = 0; i < relation.numberOfColumns(); i++) {
                this.basicSchemas.add(relation.columnNames().get(i));
            }
            List<List<String>> lines = new ArrayList<>();
            while (relation.hasNext()) {
                List<String> row = relation.next();
                lines.add(row);
            }
            for (int attrID = 0; attrID < this.basicSchemas.size(); attrID++) {
                String attrName = this.basicSchemas.get(attrID);
                String[] col_ = new String[lines.size()];
                for (int z = 0; z < lines.size(); z++) {
                    col_[z] = lines.get(z).get(attrID);
                }
                this.columnsMap.put(attrName, col_);
            }
            this.tidBegin = 0;
            this.tidEnd = this.columnsMap.get(this.basicSchemas.get(0)).length;

        } catch (FileNotFoundException | InputIterationException e) {
            log.info("Cannot load table file\n");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

        }
    }

    public Table(ArrayList<String> basicSchemas, ArrayList<String> enrichedSchemas,
                 HashMap<String, ArrayList<Integer>> schemasGraphMap,
                 int tidBegin, int tidEnd) {
        this.basicSchemas = basicSchemas;
        this.enrichedSchemas = enrichedSchemas;
        this.schemasGraphMap = schemasGraphMap;
        this.columnsMap = new HashMap<String, String[]>();
        for (String s : this.basicSchemas) {
            this.columnsMap.put(s, null);
        }
        for (String s : this.enrichedSchemas) {
            this.columnsMap.put(s, null);
        }
        this.tidBegin = tidBegin;
        this.tidEnd = tidEnd;

        this.numOfAttrs = this.basicSchemas.size() + this.enrichedSchemas.size();
    }

    public int getBasicSchemasSize() {
        return this.basicSchemas.size();
    }

    public int getRnrichedSchemasSize() {
        return this.enrichedSchemas.size();
    }

    public ArrayList<String> getBasicSchemas() {
        return this.basicSchemas;
    }

    public ArrayList<String> getEnrichedSchemas() {
        return this.enrichedSchemas;
    }

    public ArrayList<Integer> getGraphPathLabels(String attribute) {
        return this.schemasGraphMap.get(attribute);
    }

    public String[] getColumn(String attribute) {
        return this.columnsMap.get(attribute);
    }

    public int getTidBegin() {
        return this.tidBegin;
    }

    public int getTidEnd() {
        return this.tidEnd;
    }

    public int getTupleNums() {
        return this.tidEnd - this.tidBegin;
    }

    public void imputeColumn(String[] values, int attrID) {
//        this.columnsMap[this.enrichedSchemas.get(attrID)] = values;
        if (this.columnsMap == null) {
            this.columnsMap = new HashMap<>();
        }
        this.columnsMap.put(this.enrichedSchemas.get(attrID), values);
    }

    public void imputeColumn(String[] values, String schema) {
        this.columnsMap.put(schema, values);
    }

    // serialize all string of A_p (vertex matching of blocking)
    public void serialize(ArrayList<String> schemas_ap) {
        this.serials = new String[this.tidEnd - this.tidBegin];
        for (int tid = this.tidBegin; tid < this.tidEnd; tid++) {
            String s = "";
            for (String schema : schemas_ap) {
                String v_ = this.columnsMap.get(schema)[tid - this.tidBegin];
                s += v_ + " ";
            }
            this.serials[tid - this.tidBegin] = s.trim();
        }
    }

    public String[] getSerials() {
        return this.serials;
    }

    public ArrayList<String[]> getSerialsTokens() {
        return this.serialsTokens;
    }

    public ArrayList<Double[]> getEmbeddings() {
        return this.embeddings;
    }

    public void constructSerialsTokens(String limiter) {
        this.serialsTokens = Utils.generateTokens(this.serials, limiter);
    }

    public HashMap<String, ArrayList<Integer>> getInvertedIndex() {
        return this.invertedIndex;
    }


    public void constructBlockingForIndexWithLength(String limiter) {
        this.invertedIndexLength = new HashMap<String, HashMap<Integer, ArrayList<Integer>>>();
        this.tokenFreqs = new HashMap<>();
        for (int rid = 0; rid < this.serialsTokens.size(); rid++) {
            int tokensNum = this.serialsTokens.get(rid).length;
            for (String token : this.serialsTokens.get(rid)) {
                if (this.invertedIndexLength.containsKey(token)) {
                    HashMap<Integer, ArrayList<Integer>> lenMap = this.invertedIndexLength.get(token);
                    if (lenMap.containsKey(tokensNum)) {
                        lenMap.get(tokensNum).add(rid);
                    } else {
                        ArrayList<Integer> _list = new ArrayList<>();
                        _list.add(rid);
                        lenMap.put(tokensNum, _list);
                    }
                    this.tokenFreqs.put(token, this.tokenFreqs.get(token) + 1);
                } else {
                    HashMap<Integer, ArrayList<Integer>> lenMap = new HashMap<>();
                    ArrayList<Integer> _list = new ArrayList<>();
                    _list.add(rid);
                    lenMap.put(tokensNum, _list);
                    this.invertedIndexLength.put(token, lenMap);

                    this.tokenFreqs.put(token, 1);
                }
            }
        }
    }

    public void constructBlockingForIndex(String limiter) {
//        this.serialsTokens = Utils.generateTokens(this.serials, limiter);
        this.invertedIndex = new HashMap<String, ArrayList<Integer>>();
//        for(ArrayList<String> tokens : this.serialsTokens) {
        for (int rid = 0; rid < this.serialsTokens.size(); rid++) {
            for (String token : this.serialsTokens.get(rid)) {
                if (this.invertedIndex.containsKey(token)) {
                    this.invertedIndex.get(token).add(rid);
                } else {
                    ArrayList<Integer> rids = new ArrayList<Integer>();
                    rids.add(rid);
                    this.invertedIndex.put(token, rids);
                }
            }
        }
    }

    // compute the correlation
    private double computeCorr(ArrayList<String> queryTokens, Double[] queryEmbedd,
                               String[] vertexTokens, Double[] vertexEmbedd,
                               Similarity jacc, Similarity cos, double alpha) {
        ArrayList<String> vertexTokens_ = new ArrayList<String>();
        double jaccV = jacc.jaccardSimilarity(queryTokens, vertexTokens_);
        double cosV = cos.cosineSimilarity(queryEmbedd, vertexEmbedd);
        return jaccV * alpha + (1 - alpha) * cosV;
    }


    public ArrayList<Double> getTopOneCorrelationInverse(String vertexQuery, ArrayList<String> vertexQuerytokens,
                                                         Double[] vertexQueryEmbedd,
                                                         ArrayList<Integer> candsInverse,
                                                         Similarity jacc, Similarity cos, double alpha) {
        ArrayList<Double> corrArr = new ArrayList<>();
        for (Integer queryID: candsInverse) {
            double corr = this.computeCorr(vertexQuerytokens, vertexQueryEmbedd,
                    this.serialsTokens.get(queryID), this.embeddings.get(queryID), jacc, cos, alpha);
            corrArr.add(corr);
        }
        return corrArr;
    }

    public double estimateHERBlockingCost(KGraph graph, double simThreshold) {
        double cost = 0;
        for (int i = 0; i < this.serialsTokens.size(); i++) {
            String[] queryTokens = this.serialsTokens.get(i);
            int num_prefix_tokens = queryTokens.length - (int)(queryTokens.length * simThreshold) + 1;
            for (int j = 0; j < num_prefix_tokens; j++) {
                if (graph.getInvertedIndex().containsKey(queryTokens[j])) {
                    cost += graph.getInvertedIndex().get(queryTokens[j]).size();
                }
            }
        }
        return cost;
    }


    public ArrayList<Integer> blockingForEachQueryWithLength(ArrayList<String> query, double simThreshold, Similarity sim) {
//        log.info("The query is " + query);
        ArrayList<Integer> cands = new ArrayList<Integer>();
        int queryLen = query.size();
//        int num_prefix_tokens = queryLen - (int)(queryLen * simThreshold) + 1;
        int num_prefix_tokens = (int)(queryLen * (1 - simThreshold)) + 1;
        if (num_prefix_tokens > queryLen) {
            num_prefix_tokens = queryLen;
        }
        ArrayList<Integer> freqs = new ArrayList<Integer>();
        for (String token : query) {
            if(this.tokenFreqs.containsKey(token)) {
                freqs.add(this.tokenFreqs.get(token));
            } else{
                freqs.add(0);
            }
        }
        int lenSmall = (int)(Math.floor(queryLen * simThreshold));
        int lenLarge = (int)(Math.ceil(queryLen / simThreshold));
        PriorityQueue<ImmutablePair<String, Integer>> tokenFreqs = new PriorityQueue<ImmutablePair<String, Integer>>(
                new Comparator<ImmutablePair<String, Integer>>(){
                    @Override
                    public int compare(ImmutablePair<String, Integer> o1, ImmutablePair<String, Integer> o2) {
                        if (o1.getValue() < o2.getValue()) {
                            return -1;
                        } else if (o1.getValue() > o2.getValue()) {
                            return 1;
                        } else {
                            return 0;
                        }
                    }
                }
        );
        for (int i = 0; i < queryLen; i++) {
            ImmutablePair<String, Integer> pair = new ImmutablePair<>(query.get(i), freqs.get(i));
            tokenFreqs.add(pair);
        }
        // extract candidate vertices
        HashSet<Integer> set = new HashSet<Integer>();
        for (int i = 0; i < num_prefix_tokens; i++) {
            String token = tokenFreqs.poll().getKey();
            HashMap<Integer, ArrayList<Integer>> lenMap = this.invertedIndexLength.get(token);
            if (lenMap == null) {
                continue;
            }
            for(int _len = lenSmall; _len <= lenLarge; _len++) {
                ArrayList<Integer> list = lenMap.get(_len);
                if (list != null) {
                    for (Integer vid : list) {
                        set.add(vid);
                    }
                }
            }
        }
//        log.info("The number of candidates is " + set.size());
        // verify the candidates
        for (Integer vid : set) {
            String[] vertexTokens = this.serialsTokens.get(vid);
            ArrayList<String> vertexTokens_ = new ArrayList<String>();
            for (String t : vertexTokens) {
                vertexTokens_.add(t);
            }
            double simV = sim.jaccardSimilarity(query, vertexTokens_);
            if (simV >= simThreshold) {
                cands.add(vid);
            }
        }
        return cands;
    }


    public ArrayList<Integer> blockingForEachQuery(ArrayList<String> query, double simThreshold, Similarity sim) {
        ArrayList<Integer> cands = new ArrayList<Integer>();
        int queryLen = query.size();
        int num_prefix_tokens = queryLen - (int)(queryLen * simThreshold) + 1;
        if (num_prefix_tokens > queryLen) {
            num_prefix_tokens = queryLen;
        }
        ArrayList<Integer> freqs = new ArrayList<Integer>();
        for (String token : query) {
            if(this.invertedIndex.containsKey(token)) {
                freqs.add(this.invertedIndex.get(token).size());
            } else{
                freqs.add(0);
            }
        }
        PriorityQueue<ImmutablePair<String, Integer>> tokenFreqs = new PriorityQueue<ImmutablePair<String, Integer>>(
                new Comparator<ImmutablePair<String, Integer>>(){
                    @Override
                    public int compare(ImmutablePair<String, Integer> o1, ImmutablePair<String, Integer> o2) {
                        if (o1.getValue() < o2.getValue()) {
                            return -1;
                        } else if (o1.getValue() > o2.getValue()) {
                            return 1;
                        } else {
                            return 0;
                        }
                    }
                }
        );
        for (int i = 0; i < queryLen; i++) {
            ImmutablePair<String, Integer> pair = new ImmutablePair<>(query.get(i), freqs.get(i));
            tokenFreqs.add(pair);
        }
        // extract candidate vertices
        HashSet<Integer> set = new HashSet<Integer>();
        for (int i = 0; i < num_prefix_tokens; i++) {
            String token = tokenFreqs.poll().getKey();
            ArrayList<Integer> list = this.invertedIndex.get(token);
            if (list != null) {
                for (Integer vid : list) {
                    set.add(vid);
                }
            }
        }
        // verify the candidates
        for (Integer vid : set) {
            String[] vertexTokens = this.serialsTokens.get(vid);
            ArrayList<String> vertexTokens_ = new ArrayList<String>();
            for (String t : vertexTokens) {
                vertexTokens_.add(t);
            }
            double simV = sim.jaccardSimilarity(query, vertexTokens_);
            if (simV >= simThreshold) {
                cands.add(vid);
            }
        }
        return cands;
    }

    void printSampleTable() {
        for (Map.Entry<String, String[]> entry: this.columnsMap.entrySet()) {
            log.info("=========== entry ===== " + entry.getKey());
            for (int i = 0; i < entry.getValue().length; i++) {

            }
        }
    }


    /*
        extract
     */
}

