package sics.seiois.mlsserver.biz.der.enrich;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.message.BroadcastIncEnrichObj;
import sics.seiois.mlsserver.biz.der.enrich.message.IMessageAggFunctionEnrichInc;
import sics.seiois.mlsserver.biz.der.enrich.message.MessageEnrich;
import sics.seiois.mlsserver.biz.der.enrich.message.MessageEnrichInc;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;
import sics.seiois.mlsserver.model.SparkContextConfig;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class IncreEnrichmentParallel extends BatchEnrichmentParallel {


    private static final Logger logger = LoggerFactory.getLogger(IncreEnrichmentParallel.class);

    public final static int WORK_UNIT_TUPLE_NUM = 2000;
    public int NODE_NUM; // = 20;

    protected HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER; // table to KG
    //    private HashMap<Integer, ArrayList<Integer>> candsAll;
    protected HashMap<Integer, ImmutablePair<Integer, Double>> HERInverse; // KG to table
    protected AFF aff;
    protected HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HERInc; // table to KG incremental enrichment

    public IncreEnrichmentParallel(KGraph graph, Table table, Config config,
                                   HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER) {
        super(graph, table, config);
        this.HER = HER;
        this.NODE_NUM = config.getNumOfWorks();
    }

    public IncreEnrichmentParallel(KGraph graph, Table table, Config config, String option,
                                   HashMap<Integer, ImmutablePair<Integer, Double>> HER) {
        super(graph, table, config);
        this.NODE_NUM = config.getNumOfWorks();
    }

    // should ONLY be used when prepareAuxStructureInc has been executed, this is the variants and tested as baselines
    public KGraph getUpdatedGraph() {
        return this.graph;
    }

    public void prepareAuxStructureInc(double sampleRatio) {
        // generate the edge operations
        Update update = new Update(this.graph, sampleRatio);
        // prepare the affected vertices in KG
        this.aff = new AFF(update, this.config.getPathhLenK(), this.config.getPathLabelOption(),
                this.config.getPathsBlocking(), this.graph, this.table.getEnrichedSchemas());
        // construct the inverted index for table
//        this.table.constructBlockingForIndex(Config.LIMITER);
        this.table.constructBlockingForIndexWithLength(config.LIMITER);
        // assume graph and table embedding have been loaded
        this.HERInverse = new HashMap<>();
        this.HERInc = new HashMap<>();
//        for (Map.Entry<Integer, ImmutablePair<Integer, Double>> entry : this.HER.entrySet()) {
//            Integer key = entry.getValue().getLeft();
//            Double corr = entry.getValue().getRight();
//            ImmutablePair<Integer, Double> pair = new ImmutablePair<>(entry.getKey(), corr);
//            HERInverse.put(key, pair);
//        }
    }

    public void incEnrichmentParallel(String taskId, SparkSession spark, SparkContextConfig sparkContextConfig) {
        int affectedVIDNumEach = this.aff.getAffectdedVertices().size() / NODE_NUM;
        ArrayList<AFF> affs = new ArrayList<>();
        if (this.aff.getAffectdedVertices().size() == 0) {
            affs.add(this.aff);
        } else {
            if (this.aff.getAffectdedVertices().size() <= NODE_NUM) {
                affectedVIDNumEach = 1;
            }
            affs = this.aff.splitAFFUniform(affectedVIDNumEach);
        }
//        ArrayList<ImmutablePair<Double, AFF>> affsInfo = new ArrayList<>();
//
//        affsInfo.sort(new Comparator<ImmutablePair<Double, AFF>>() {
//                            @Override
//                            public int compare(ImmutablePair<Double, AFF> o1, ImmutablePair<Double, AFF> o2) {
//                                if (o1.getKey() < o2.getKey()) {
//                                    return -1;
//                                } else if (o1.getKey() > o2.getKey()) {
//                                    return 1;
//                                }
//                                return 0;
//                            }
//                        }
//
//        );
//        ArrayList<ArrayList<AFF>> block = new ArrayList<>();
////        ArrayList<Double> costs = new ArrayList<>();
//        Double[] costs = new Double[NODE_NUM];
//        for (int i = 0; i < NODE_NUM; i++) {
//            ArrayList<AFF> tabs = new ArrayList<>();
//            block.add(tabs);
//            costs[i] = 0.0;
//        }
//        for (ImmutablePair<Double, AFF> pair : affsInfo) {
//            double minCost = costs[0];
//            int sc = 0;
//            for (int i  = 1; i < costs.length; i++) {
//                if (minCost > costs[i]) {
//                    minCost = costs[i];
//                    sc = i;
//                }
//            }
//            block.get(sc).add(pair.getValue());
//            costs[sc] += pair.getKey();
//        }
//
//        ArrayList<WorkUnitIE> workUnitsIE = new ArrayList<>();
//        for (int i = 0; i < NODE_NUM; i++) {
//            if (block.get(i).size() <= 0) {
//                continue;
//            }
//
//        }

        Table tableLite = new Table(this.table.getBasicSchemas(), this.table.getEnrichedSchemas(), this.table.getSchemasGraphMap(),
                this.table.getEmbeddings(), this.table.getTidBegin(), this.table.getTidEnd(), this.table.getSerials(),
                this.table.getSerialsTokens(), this.table.getInvertedIndexLength(), this.table.getTokenFreqs());

        ArrayList<WorkUnitIE> workUnitsIE = new ArrayList<>();

        for (int i = 0; i < NODE_NUM; i++) {
            if (i >= affs.size()) {
                continue;
            }
//            WorkUnitIE workUnitIE = new WorkUnitIE(new Table(), this.config, this.HER, this.aff);
            WorkUnitIE workUnitIE = new WorkUnitIE(new Table(), this.config, this.HER, affs.get(i));
            workUnitsIE.add(workUnitIE);
        }
//        List<MessageEnrichInc> messages = this.runInc(workUnitsIE, taskId, spark, sparkContextConfig, tableLite);
        List<MessageEnrichInc> messages = this.runIncLocal(workUnitsIE, tableLite, this.graph);
        logger.info("Finish incremental enrichment");
    }

    public List<MessageEnrichInc> runInc(ArrayList<WorkUnitIE> workUnits, String taskId, SparkSession spark,
                                   SparkContextConfig sparkContextConfig, Table table) {

        int K = 3;
        JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());

        BroadcastIncEnrichObj broadcastIncEnrichObj = new BroadcastIncEnrichObj(table);
        Broadcast<BroadcastIncEnrichObj> scInput = sc.broadcast(broadcastIncEnrichObj);

        List<MessageEnrichInc> messages = sc.parallelize(workUnits, workUnits.size()).map(task ->{

            BroadcastIncEnrichObj bIncEnrichObj = scInput.getValue();
            Table tableLite = bIncEnrichObj.getTable();
            task.setTable(tableLite);
            IncreEnrichment incEnrichment = task.getIncreEnrichment();
            incEnrichment.setAff(task.getAff());
//            incEnrichment.setParallelVariables(bIncEnrichObj.getHER(), bIncEnrichObj.getHERInverse());
            incEnrichment.incEnrichmentTopK(K);
            AFF aff = incEnrichment.getAff();
            MessageEnrichInc messageEnrichInc = new MessageEnrichInc(aff.getAffectedTuplesAllAttrs());
            List<MessageEnrichInc> messageEnrichIncs = new ArrayList<>();
            messageEnrichIncs.add(messageEnrichInc);
            return messageEnrichIncs;
        }).aggregate(null, new IMessageAggFunctionEnrichInc(), new IMessageAggFunctionEnrichInc());
        return messages;
    }

    public List<MessageEnrichInc> runIncLocal(ArrayList<WorkUnitIE> workUnits, Table tableLite, KGraph graph) {
        List<MessageEnrichInc> messages = new ArrayList<>();
        int K = 3;
        for(WorkUnitIE task : workUnits) {
            task.setTable(tableLite);
            task.setGraph(graph);
            IncreEnrichment incEnrichment = task.getIncreEnrichment();
            incEnrichment.setAff(task.getAff());
//            incEnrichment.setParallelVariables(this.HER, this.HERInverse);
            incEnrichment.incEnrichmentTopK(K);
            AFF aff = incEnrichment.getAff();
            MessageEnrichInc messageEnrichInc = new MessageEnrichInc(aff.getAffectedTuplesAllAttrs());
            messages.add(messageEnrichInc);
        }
        return messages;
    }


    // parallel incremental enrichment in a single machine
    public void incEnrichmentParallelThread(int K) {
        int affectedVIDNumEach = this.aff.getAffectdedVertices().size() / NODE_NUM;
        ArrayList<AFF> affs = new ArrayList<>();
        if (this.aff.getAffectdedVertices().size() == 0) {
            affs.add(this.aff);
        } else {
            if (this.aff.getAffectdedVertices().size() <= NODE_NUM) {
                affectedVIDNumEach = 1;
            }
            affs = this.aff.splitAFFUniform(affectedVIDNumEach);
        }
//        ArrayList<ImmutablePair<Double, AFF>> affsInfo = new ArrayList<>();
//
//        affsInfo.sort(new Comparator<ImmutablePair<Double, AFF>>() {
//                            @Override
//                            public int compare(ImmutablePair<Double, AFF> o1, ImmutablePair<Double, AFF> o2) {
//                                if (o1.getKey() < o2.getKey()) {
//                                    return -1;
//                                } else if (o1.getKey() > o2.getKey()) {
//                                    return 1;
//                                }
//                                return 0;
//                            }
//                        }
//
//        );
//        ArrayList<ArrayList<AFF>> block = new ArrayList<>();
////        ArrayList<Double> costs = new ArrayList<>();
//        Double[] costs = new Double[NODE_NUM];
//        for (int i = 0; i < NODE_NUM; i++) {
//            ArrayList<AFF> tabs = new ArrayList<>();
//            block.add(tabs);
//            costs[i] = 0.0;
//        }
//        for (ImmutablePair<Double, AFF> pair : affsInfo) {
//            double minCost = costs[0];
//            int sc = 0;
//            for (int i  = 1; i < costs.length; i++) {
//                if (minCost > costs[i]) {
//                    minCost = costs[i];
//                    sc = i;
//                }
//            }
//            block.get(sc).add(pair.getValue());
//            costs[sc] += pair.getKey();
//        }
//
//        ArrayList<WorkUnitIE> workUnitsIE = new ArrayList<>();
//        for (int i = 0; i < NODE_NUM; i++) {
//            if (block.get(i).size() <= 0) {
//                continue;
//            }
//
//        }

        Table tableLite = new Table(this.table.getBasicSchemas(), this.table.getEnrichedSchemas(), this.table.getSchemasGraphMap(),
                this.table.getEmbeddings(), this.table.getTidBegin(), this.table.getTidEnd(), this.table.getSerials(),
                this.table.getSerialsTokens(), this.table.getInvertedIndexLength(), this.table.getTokenFreqs());

        // parallel incremental enrichment
        ArrayList<MessageEnrichInc> messageEnrichIncs = new ArrayList<>();
        ArrayList<WorkUnitIEThread> workUnitsIE = new ArrayList<>();

        for (int i = 0; i < NODE_NUM; i++) {
            if (i >= affs.size()) {
                continue;
            }
//            WorkUnitIE workUnitIE = new WorkUnitIE(new Table(), this.config, this.HER, this.aff);
            WorkUnitIEThread workUnitIE = new WorkUnitIEThread(new Table(), this.config, this.HER, affs.get(i), K, messageEnrichIncs);
            workUnitIE.setGraph(this.graph);
            workUnitIE.setTable(tableLite);
            workUnitsIE.add(workUnitIE);
        }
//        List<MessageEnrichInc> messages = this.runInc(workUnitsIE, taskId, spark, sparkContextConfig, tableLite);
//        List<MessageEnrichInc> messages = this.runIncLocal(workUnitsIE, tableLite, this.graph);

        ExecutorService pool = Executors.newFixedThreadPool(NODE_NUM);
        for (WorkUnitIEThread workUnitIEThread: workUnitsIE) {
            pool.execute(workUnitIEThread);
        }

        pool.shutdown();
        try {
            while (true) {
                if (pool.isTerminated()) {
                    break;
                }
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            logger.error("", e);
        }
        logger.info("Finish incremental enrichment");
    }

}
