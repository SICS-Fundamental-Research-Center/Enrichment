package sics.seiois.mlsserver.biz.der.enrich.graph;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public class Vertex implements Serializable {
    private static final long serialVersionUID = 2191087334458611217L;

    private String name;
    private int vid;
    private int type; // 1 means centric nodes, and 0 means other nodes.
    //    private LinkedList<Edge> edgeList;
    private HashMap<Integer, Edge> edgeMaps;

    private HashMap<Integer, Edge> reverseEdgeMaps;

    public HashMap<Integer, Edge> getReverseEdges() {
        return this.reverseEdgeMaps;
    }

    public int getType() {
        return this.type;
    }

    public Vertex(int vid, String name, int type){
        this.vid = vid;
        this.name = name;
        this.type = type;
//        edgeList = new LinkedList<>();
        this.edgeMaps = new HashMap<Integer, Edge>();
        this.reverseEdgeMaps = new HashMap<>();
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getVid() {
        return this.vid;
    }

    public String getName(){
        return name;
    }

    public HashMap<Integer, Edge> getEdges(){
        return this.edgeMaps;
    }

    public Vertex getNextVertex(Integer label) {
        if (this.edgeMaps.containsKey(label)) {
            return this.edgeMaps.get(label).getDestVertex();
        } else{
            return null;
        }
    }

    public Edge getNextEdge(String label) {
        if (this.edgeMaps.containsKey(label)) {
            return this.edgeMaps.get(label);
        } else{
            return null;
        }
    }
}
