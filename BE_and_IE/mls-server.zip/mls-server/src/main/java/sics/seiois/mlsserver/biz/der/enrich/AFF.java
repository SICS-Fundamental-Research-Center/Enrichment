package sics.seiois.mlsserver.biz.der.enrich;

import breeze.linalg.support.CanCollapseAxis;
import com.google.inject.internal.cglib.core.$ProcessArrayCallback;
import jdk.nashorn.internal.ir.annotations.Immutable;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.graph.Vertex;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;

import javax.management.ImmutableDescriptor;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class AFF implements Serializable {
    private static Logger log = LoggerFactory.getLogger(AFF.class);

    private static final long serialVersionUID = 1397743211146642224L;

    private HashSet<Integer> affectdedVertices;

    private HashMap<Integer, ArrayList<Integer>> tupleToVertexCands;

    private HashMap<Integer, String> affectedSerials;
    private HashMap<Integer, String[]> affectedSerialsTokens;
    private HashMap<Integer, Double[]> affectedEmbeddings;

    private ArrayList<HashMap<Integer, String>> affectedEnrichedValuesForTableSchemas;
    private ArrayList<String> enrichedSchemas;
    private ArrayList<HashMap<Integer, String>> affectedTuplesAllAttrs;

    public Update update;
    private int k;
    private String option;
    private ArrayList<ArrayList<Integer>> paths;

    public ArrayList<HashMap<Integer, String>> getAffectedTuplesAllAttrs() {
        return this.affectedTuplesAllAttrs;
    }

    public double estimateHERBlockingCost(Table table, double simThreshold) {
        double cost = 0;
        for (Integer vid : this.affectdedVertices) {
            String[] queryTokens = this.affectedSerialsTokens.get(vid);
            int num_prefix_tokens = queryTokens.length - (int)(queryTokens.length * simThreshold) + 1;
            for (int j = 0; j < num_prefix_tokens; j++) {
                if (table.getInvertedIndex().containsKey(queryTokens[j])) {
                    cost += table.getInvertedIndex().get(queryTokens[j]).size();
                }
            }
        }
        return cost;
    }

    // copy, for parallel split tasks
    public AFF(HashSet<Integer> affectdedVertices, HashMap<Integer, String> affectedSerials,
               HashMap<Integer, String[]> affectedSerialsTokens, HashMap<Integer, Double[]> affectedEmbeddings,
               ArrayList<HashMap<Integer, String>> affectedEnrichedValuesForTableSchemas, ArrayList<String> enrichedSchemas) {
        this.affectdedVertices = affectdedVertices;
        this.affectedSerials = affectedSerials;
        this.affectedSerialsTokens = affectedSerialsTokens;
        this.affectedEmbeddings = affectedEmbeddings;
        this.affectedEnrichedValuesForTableSchemas = affectedEnrichedValuesForTableSchemas;
        this.enrichedSchemas = enrichedSchemas;
    }

    public ArrayList<AFF> splitAFFUniform(int affectedVIDNumEach) {
        int affectedVNumTotal = this.affectdedVertices.size();
        ArrayList<Integer> affectedVerticesArr = new ArrayList<>(this.affectdedVertices);
        ArrayList<ImmutablePair<Integer, Integer>> vidIntervals = new ArrayList<>();
        int sc = 0;
        for(;sc < affectedVNumTotal; sc += affectedVIDNumEach) {
            int bb = sc;
            int ee = sc + affectedVIDNumEach;
            if (ee >= affectedVNumTotal) {
                ee = affectedVNumTotal;
            }
            vidIntervals.add(new ImmutablePair<>(bb, ee));
        }
        ArrayList<AFF> affs = new ArrayList<>();
        for (int i = 0; i < vidIntervals.size(); i++) {
            int vidBegin = vidIntervals.get(i).getLeft();
            int vidEnd = vidIntervals.get(i).getRight();
            HashSet<Integer> affectedVerticesSub = new HashSet<>();
            for (int vv = vidBegin; vv < vidEnd; vv++) {
                affectedVerticesSub.add(affectedVerticesArr.get(vv));
            }
            HashMap<Integer, String> affectedSerialsSub = new HashMap<>();
            for (Integer vv : affectedVerticesSub) {
                affectedSerialsSub.put(vv, this.affectedSerials.get(vv));
            }
            HashMap<Integer, String[]> affectedSerialsTokensSub = new HashMap<>();
            for (Integer vv : affectedVerticesSub) {
                affectedSerialsTokensSub.put(vv, this.affectedSerialsTokens.get(vv));
            }
            HashMap<Integer, Double[]> affectedEmbeddingsSub = new HashMap<>();
            for (Integer vv : affectedVerticesSub) {
                affectedEmbeddingsSub.put(vv, this.affectedEmbeddings.get(vv));
            }
            ArrayList<HashMap<Integer, String>> affectedEnrichedValuesForTableSchemasSub = new ArrayList<>();
            for (int z = 0; z < this.enrichedSchemas.size(); z++) {
                String attr = this.enrichedSchemas.get(z);
                HashMap<Integer, String> enrichedV = new HashMap<>();
                for (Integer vv : affectedVerticesSub) {
                    enrichedV.put(vv, this.affectedEnrichedValuesForTableSchemas.get(z).get(vv));
                }
                affectedEnrichedValuesForTableSchemasSub.add(enrichedV);
            }
            AFF af = new AFF(affectedVerticesSub, affectedSerialsSub, affectedSerialsTokensSub, affectedEmbeddingsSub,
                    affectedEnrichedValuesForTableSchemasSub, this.enrichedSchemas);
            affs.add(af);
        }
        return affs;
    }

    public AFF (Update update, int k, String option, ArrayList<ArrayList<Integer>> paths,
                KGraph graph, ArrayList<String> enrichedSchemas) {
        this.update = update;
        this.k = k;
        this.option = option;
        this.paths = paths;

        this.affectedSerials = new HashMap<>();
        this.affectedSerialsTokens = new HashMap<>();
        this.affectedEmbeddings = new HashMap<>();
        this.setAffectdedVertices();
        this.setAffectedSerialsTokens();
        this.setAffectedEmbeddings();
        this.setAffectedEnrichedValuesForTableSchemas(graph, enrichedSchemas);
        log.info("After update, the number of vertices in AFF is " + this.getAffectdedVertices().size());
    }

    public HashSet<Integer> getAffectdedVertices() {
        return this.affectdedVertices;
    }

    public HashMap<Integer, String> getAffectedSerials() {
        return this.affectedSerials;
    }

    public HashMap<Integer, String[]> getAffectedSerialsTokens() {
        return this.affectedSerialsTokens;
    }

    public HashMap<Integer, Double[]> getAffectedEmbeddings() {
        return this.affectedEmbeddings;
    }

    // paths are only from base table
    public void setAffectdedVertices() {
        this.affectdedVertices = this.update.computeAFFVertices(k, option, paths, affectedSerials);
    }

    public void setAffectedSerialsTokens() {
        Utils.generateTokens(this.affectedSerialsTokens, this.affectedSerials, Config.LIMITER);
    }

    public void setTupleToVertexCands(HashMap<Integer, ArrayList<Integer>> candsAll) {
        this.tupleToVertexCands = candsAll;
    }

    public void setAffectedEmbeddings() {
        for (Map.Entry<Integer, String> entry: this.affectedSerials.entrySet()) {
            Double[] m = new Double[20];
            for (int z = 0; z < m.length; z++) {
                m[z] = 1.0;
            }
            this.affectedEmbeddings.put(entry.getKey(), m);
        }
    }

    public void setAffectedEnrichedValuesForTableSchemas(KGraph graph, ArrayList<String> enrichedSchemas)  {
        this.enrichedSchemas = enrichedSchemas;
        this.affectedEnrichedValuesForTableSchemas = new ArrayList<>();
        for (int i = 0; i < this.enrichedSchemas.size(); i++) {
            String attr = this.enrichedSchemas.get(i);
            HashMap<Integer, String> enrichedV = new HashMap<>();
            for (Integer vid : this.affectdedVertices) {
                int sc = graph.getCenterVIDsMap().get(vid);
                enrichedV.put(vid, graph.getEnrichedValuesForTableSchemas().get(attr).get(sc));
            }
            this.affectedEnrichedValuesForTableSchemas.add(enrichedV);
        }
    }

    /*
        output: (1) the arraylist is the same of enrichedSchemas;
        (2) Key is the tuple ID
        (3) value is the imputed value
     */
    public void affectedDataImputation(HashMap<Integer, ImmutablePair<Integer, Double>> HERInc) {
        this.affectedTuplesAllAttrs = new ArrayList<>(); //
        for (int z = 0; z < this.enrichedSchemas.size(); z++) {
            HashMap<Integer, String> affectedTuplesOneAttr = new HashMap<>();
            for (Map.Entry<Integer, ImmutablePair<Integer, Double>> her : HERInc.entrySet()) {
                int vid = her.getValue().getLeft();
                int tid = her.getKey();
                affectedTuplesOneAttr.put(tid, this.affectedEnrichedValuesForTableSchemas.get(z).get(vid));
            }
            affectedTuplesAllAttrs.add(affectedTuplesOneAttr);
        }
    }

}
