package sics.seiois.mlsserver.biz.der.enrich.message;

import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;

import java.io.Serializable;

public class BroadcastEnrichObj implements Serializable {
    private static final long serialVersionUID = 116197331048687017L;

    private KGraph graph;

    public BroadcastEnrichObj(KGraph graph) {
        this.graph = graph;
    }

    public KGraph getGraph() {
        return this.graph;
    }
}
