package sics.seiois.mlsserver.biz.der.enrich;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.hadoop.util.hash.Hash;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class IncreEnrichment extends BatchEnrichment implements Serializable {

    private static final Logger logger = LoggerFactory.getLogger(IncreEnrichment.class);
    private static final long serialVersionUID = 1059495274327223070L;
//    private KGraph graph;
//    private Table table;
//    private Config config;
//    private Similarity jacc;
//    private Similarity cos;
    protected HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER; // table to KG
//    private HashMap<Integer, ArrayList<Integer>> candsAll;
    protected HashMap<Integer, ImmutablePair<Integer, Double>> HERInverse; // KG to table
    protected AFF aff;
    protected HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HERInc; // table to KG incremental enrichment

    public IncreEnrichment(KGraph graph, Table table, Config config,
                           HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER) {
        // assume batch enrichment has been processed
        super(graph, table, config);
//        this.graph = graph;
//        this.table = table;
//        this.config = config;
//        this.jacc = jacc;
//        this.cos = cos;
        this.HER = HER;
//        this.candsAll = candsAll;
    }

    public AFF getAff() {
        return this.aff;
    }

    public void setAff(AFF aff) {
        this.aff = aff;
    }

    public IncreEnrichment(Table table, Config config, HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER) {
        super(null, table, config);
        this.HER = HER;
    }

    public void setTable(Table table) {
        this.table = table;
    }

    public void setGraph(KGraph graph) {
        this.graph = graph;
    }

//    public void setParallelVariables(HashMap<Integer, ImmutablePair<Integer, Double>> HER,
//                                     HashMap<Integer, ImmutablePair<Integer, Double>> HERInverse) {
//        this.HER = HER;
//        this.HERInverse = HERInverse;
//        this.HERInc = new HashMap<>();
//    }

    public void prepareAuxStructureInc(double sampleRatio) {
        // generate the edge operations
        Update update = new Update(this.graph, sampleRatio);
        // prepare the affected vertices in KG
        this.aff = new AFF(update, this.config.getPathhLenK(), this.config.getPathLabelOption(),
                this.config.getPathsBlocking(), this.graph, this.table.getEnrichedSchemas());
        // construct the inverted index for table
        this.table.constructBlockingForIndex(Config.LIMITER);
        // assume graph and table embedding have been loaded
        this.HERInverse = new HashMap<>();
        this.HERInc = new HashMap<>();
//        for (Map.Entry<Integer, ImmutablePair<Integer, Double>> entry : this.HER.entrySet()) {
//            Integer key = entry.getValue().getLeft();
//            Double corr = entry.getValue().getRight();
//            ImmutablePair<Integer, Double> pair = new ImmutablePair<>(entry.getKey(), corr);
//            HERInverse.put(key, pair);
//        }
    }

    private ArrayList<Integer> HERBlockingForEachQueryInverse(int vertexID) {
//        String vertexQuery = graph.getSerials()[vertexID];
        String vertexQuery = this.aff.getAffectedSerials().get(vertexID);
//        String[] vertexQueryTokens_ = graph.getSerialsTokens().get(vertexID);
        String[] vertexQueryTokens_ = this.aff.getAffectedSerialsTokens().get(vertexID);
        if (vertexQueryTokens_.length <= 0 || vertexQuery.trim().equals("")) {
            return null;
        }
        ArrayList<String> vertexQueryTokens = new ArrayList<>(Arrays.asList(vertexQueryTokens_));
//        ArrayList<Integer> candsInverse = table.blockingForEachQuery(vertexQueryTokens, config.getJaccThreshold(), jacc);
        ArrayList<Integer> candsInverse = table.blockingForEachQueryWithLength(vertexQueryTokens, config.getJaccThreshold(), jacc);
        return candsInverse;
    }

    private ArrayList<Double> VertexMatchingForEachQueryInverse(int vertexID, ArrayList<Integer> candsInverse) {
        // only check whether vertexID is the top-1 one
//        String vertexQuery = graph.getSerials()[vertexID];
        String vertexQuery = this.aff.getAffectedSerials().get(vertexID);
//        String[] vertexQueryTokens_ = graph.getSerialsTokens().get(vertexID);
        String[] vertexQueryTokens_ = this.aff.getAffectedSerialsTokens().get(vertexID);
        ArrayList<String> vertexQueryTokens = new ArrayList<>(Arrays.asList(vertexQueryTokens_));

//        Double[] vertexQueryEmbedd = graph.getEmbeddings().get(vertexID);
        Double[] vertexQueryEmbedd = this.aff.getAffectedEmbeddings().get(vertexID);
        ArrayList<Double> corrArrs = table.getTopOneCorrelationInverse(vertexQuery, vertexQueryTokens,
                vertexQueryEmbedd, candsInverse, this.jacc, this.cos, 0.2);
        return corrArrs;
    }

    // reorganize top-K; assume arr is sorted in the decreasing order
    // return True if there are changes of V_t, else return False
    private boolean reviseTopKArray(ArrayList<ImmutablePair<Integer, Double>> arr, int vid, double corr, int K) {
        // check if the size is smaller than K
        if (arr == null || arr.size() < K) {
//            arr.add(new ImmutablePair<>(vid, corr));
            return true;
        }
        // find the smallest one
        int index = 0;
        double corr_small = arr.get(0).getRight();
        for (int i = 1; i < arr.size(); i++) {
            if (arr.get(i).getRight() < corr_small) {
                index = i;
                corr_small = arr.get(i).getRight();
            }
        }
        if (corr > corr_small) {
//            arr.set(index, new ImmutablePair<>(vid, corr));
            return true;
        }
        return false;
    }

    public void incEnrichmentTopK(int K) {
        // first construct HERInc of incremental enrichment
        this.HERInc = new HashMap<>();
        logger.info("The number of affected vertices is " + this.aff.getAffectdedVertices().size());
        for (Integer vid : this.aff.getAffectdedVertices()) {
//            logger.info("Process Vertex VID = " + vid);
            ArrayList<Integer> candsInverse = this.HERBlockingForEachQueryInverse(vid);
//            logger.info("HER blocking finish VID = " + vid);
            if (candsInverse == null) {
                continue;
            }
            ArrayList<Double> corrsInverse = this.VertexMatchingForEachQueryInverse(vid, candsInverse);
//            logger.info("Vertex Match finish VID = " + vid);
            for (int i = 0; i < candsInverse.size(); i++) {
                int queryID = candsInverse.get(i);
                double corr = corrsInverse.get(i);
                if (!this.HERInc.containsKey(queryID)) {
                    // this.HERInc.put(queryID, new ImmutablePair<>(vid, corr));
                    boolean flag = this.reviseTopKArray(this.HER.get(queryID), vid, corr, K);
                    if (flag) {
                        ArrayList<ImmutablePair<Integer, Double>> arr = new ArrayList<>();
                        arr.add(new ImmutablePair<>(vid, corr));
                        this.HERInc.put(queryID, arr);
                    }
                } else {
                    boolean flag = this.reviseTopKArray(this.HERInc.get(queryID), vid, corr, K);
                    if (flag) {
                        this.HERInc.get(queryID).add(new ImmutablePair<>(vid, corr));
                    }
//                    if (this.HERInc.get(queryID).getRight() < corr) {
//                        this.HERInc.put(queryID, new ImmutablePair<>(vid, corr));
//                    }
                }
            }
//            logger.info("HER update finish VID = " + vid);
        }
//        this.PopulateAll(this.HERInc);
//        logger.info("Populate start all");
        this.incPopluateAllTopK(this.HERInc);
//        logger.info("Populate finish all");
    }

    private void incPopluateAll(HashMap<Integer, ImmutablePair<Integer, Double>> HERInc) {
        this.aff.affectedDataImputation(HERInc);
    }

    private void incPopluateAllTopK(HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HERInc) {
        // this.aff.affectedDataImputation(HERInc);
        this.graph.dataImputationTopK(HERInc, this.table, this.cos, config.getPathLabelOption());
    }

}
