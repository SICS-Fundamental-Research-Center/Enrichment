package sics.seiois.mlsserver.biz.der.enrich;

import sics.seiois.mlsserver.biz.der.enrich.graph.Edge;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.graph.Vertex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Update implements Serializable {

    private static final long serialVersionUID = 1035740202251110624L;

    private KGraph graph;
    private ArrayList<Edge> insertEdges;
    private ArrayList<Edge> deleteEdges;

    public Update(KGraph graph, double sampleRatio) {
        this.graph = graph;
        double insertSampleRatio = sampleRatio / 2.0;
        double deleteSampleRatio = sampleRatio - insertSampleRatio;
        this.insertEdges = this.sampleInsertion(insertSampleRatio);
        this.deleteEdges = this.sampleDeletion(deleteSampleRatio);
        this.graph.generateReverseNodesMap();
    }


    /*
        update graph with one edge operation
     */
    private void updateGraphWithOneEdge(Edge e, String updateOpinion) {
        e.setIfUpdate();
        Vertex v_src = e.getSrcVertex();
        v_src = this.graph.getNodesMap().get(v_src.getVid());
        // reverse
        Vertex v_tgt = this.graph.getNodesMap().get(e.getDestVertex().getVid());
        if (updateOpinion.equals("insert")) {
            v_src.getEdges().put(e.getLabel(), e);
            v_tgt.getReverseEdges().put(e.getLabel(), e);
        } else {
            v_src.getEdges().remove(e.getLabel());
            v_tgt.getReverseEdges().remove(e.getLabel());

        }
    }

    // retrieve all affected vertices with the same types of label
    public HashSet<Integer> retrieveAffectedVertices(int k) {
        HashSet<Integer> affectedVertices = new HashSet<>();
        for (Edge e : this.insertEdges) {
            Vertex v_pivot = e.getSrcVertex();
            this.reverseAffectVerticesOneOPT(affectedVertices, v_pivot, 0, k);
            // update graph
            this.updateGraphWithOneEdge(e, "insert");
        }
        for (Edge e : this.deleteEdges) {
            Vertex v_pivot = e.getSrcVertex();
            this.reverseAffectVerticesOneOPT(affectedVertices, v_pivot, 0, k);
            // update graph
            this.updateGraphWithOneEdge(e, "delete");
        }
        return affectedVertices;
    }

    public HashSet<Integer> computeAFFVertices(int k, String option, ArrayList<ArrayList<Integer>> paths, HashMap<Integer, String> affectedSerials) {
        HashSet<Integer> affectedVIDs = this.retrieveAffectedVertices(k);
        this.graph.serializeBaseUpdate(affectedVIDs, affectedSerials, paths, option);
        return affectedVIDs;
    }

    private void reverseAffectVerticesOneOPT(HashSet<Integer> affectedVertices, Vertex v_pivot, int count, int k) {
//        Vertex v_pivot = e.getSrcVertex();
        if (v_pivot.getType() == 1) {
            affectedVertices.add(v_pivot.getVid());
        }
//        int count = 0;
        if (count < k - 1) {
            for(Map.Entry<Integer, Edge> entry: v_pivot.getReverseEdges().entrySet()) {
                Edge e = entry.getValue();
                this.reverseAffectVerticesOneOPT(affectedVertices, e.getSrcVertex(), count + 1, k);
            }
        }
    }

    private void randomSet(int min, int max, int n, HashSet<Integer> set) {
        if (n > (max - min + 1) || max < min) {
           return;
        }
        for (int i = 0; i < n; i++) {
            int num = (int) (Math.random() * (max - min)) +min;
            set.add(num);
        }
        int _size = set.size();
        if (_size < n) {
            randomSet(min, max, n - _size, set);
        }
    }

    public ArrayList<Edge> sampleDeletion(double deleteSampleRatio) {
        ArrayList<Edge> deleteEdges = new ArrayList<>();
        int edgeNum = graph.getEdgeNum();
//        for (Map.Entry<Integer, Vertex> entry: this.graph.getNodesMap().entrySet()) {
//            edgeNum += entry.getValue().getEdges().size();
//        }
        int sampleEdgeNum = (int)(edgeNum * deleteSampleRatio);
        HashSet<Integer> deleteEdgesSC = new HashSet<>();
        this.randomSet(0, edgeNum - 1, sampleEdgeNum, deleteEdgesSC);
        int count = 0;
        for (Map.Entry<Integer, Vertex> entry: this.graph.getNodesMap().entrySet()) {
            Vertex v = entry.getValue();
            for (Map.Entry<Integer, Edge> entity_ : v.getEdges().entrySet()) {
                if (deleteEdgesSC.contains(count)) {
                    deleteEdges.add(entity_.getValue());
                }
                count ++;
            }
        }
        return deleteEdges;
    }

    // (0, 1), (0, 2), (1, 2), (1, 0), (2, 0), (2, 1)
    // 0*3+1, 0*3+2, 1*3+2, 1*3+0, 2*3+0, 2*3+1
    // 1, 2, 5, 3, 6, 7
    private ArrayList<Edge> sampleInsertion(double insertSampleRatio) {
        ArrayList<Edge> insertEdges = new ArrayList<>();
        int edgeNum = this.graph.getEdgeNum();
        int sampleEdgeNum = (int)(edgeNum * insertSampleRatio);
        long vertexNum = this.graph.getNodesMap().size();
        long fullConnectedEdgeNum = vertexNum * vertexNum;
        HashSet<Long> existEdges = new HashSet<>();
        HashMap<String, Integer> vertexTypeEdgeType = new HashMap<>();
        for (Map.Entry<Integer, Vertex> entry: this.graph.getNodesMap().entrySet()) {
            String srcLabel = entry.getValue().getName();
            for (Map.Entry<Integer, Edge> entry1: entry.getValue().getEdges().entrySet()) {
                String tgtLabel = entry1.getValue().getDestVertex().getName();
                String key = srcLabel + "<->" + tgtLabel;
                if (! vertexTypeEdgeType.containsKey(key)) {
                    vertexTypeEdgeType.put(key, entry1.getValue().getLabel());
                }
                existEdges.add(((long)entry.getKey()) * vertexNum + (long)(entry1.getValue().getDestVertex().getVid()));
            }
        }
        int count = 0;
        while (count < sampleEdgeNum) {
            long num = (long) (Math.random() * (fullConnectedEdgeNum - 1 - 0)) + 0;
            int v_1 = (int) (num / vertexNum);
            int v_2 = (int) (num % vertexNum);
            if (v_1 == v_2 || existEdges.contains(num)) {
                continue;
            }
            int edgeLabel = -1; // "SEP";
            Vertex vv_1 = this.graph.getNodesMap().get(v_1);
            Vertex vv_2 = this.graph.getNodesMap().get(v_2);
            String key = vv_1.getName() + "<->" + vv_2.getName();
            if (vertexTypeEdgeType.containsKey(key)) {
                edgeLabel = vertexTypeEdgeType.get(key);
            }
            Edge edge = new Edge(vv_1, vv_2, edgeLabel);
            insertEdges.add(edge);

            count ++;
        }
        return insertEdges;
    }
}

