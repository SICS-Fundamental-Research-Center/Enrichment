package sics.seiois.mlsserver.biz.der.enrich.test;

import sics.seiois.mlsserver.biz.der.enrich.BatchEnrichment;
import sics.seiois.mlsserver.biz.der.enrich.BatchEnrichmentParallel;

public class TestEnrichment {

    public static void main(String args[]) {

    }
}
