package sics.seiois.mlsserver.biz.der.enrich;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.KryoSerializable;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import org.apache.commons.lang3.tuple.ImmutablePair;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;

import javax.management.ImmutableDescriptor;
import java.util.ArrayList;
import java.util.HashMap;

public class WorkUnitIE implements KryoSerializable {
    private IncreEnrichment increEnrichment;
    private AFF aff;

    public WorkUnitIE(Table table, Config config, HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER,
                      AFF aff) {
        this.increEnrichment = new IncreEnrichment(table, config, HER);
        this.aff = aff;
    }

    public IncreEnrichment getIncreEnrichment(){
        return this.increEnrichment;
    }

    public AFF getAff() {
        return this.aff;
    }

    public void setTable(Table table) {
        this.increEnrichment.setTable(table);
    }

    public void setGraph(KGraph graph) {
        this.increEnrichment.setGraph(graph);
    }

    @Override
    public void write(Kryo kryo, Output output) {
        kryo.writeObject(output, increEnrichment);
        kryo.writeObject(output, aff);
    }

    @Override
    public void read(Kryo kryo, Input input) {
        this.increEnrichment = kryo.readObject(input, IncreEnrichment.class);
        this.aff = kryo.readObject(input, AFF.class);
    }
}
