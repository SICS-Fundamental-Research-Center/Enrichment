package sics.seiois.mlsserver.biz.der.enrich.message;

import org.apache.spark.api.java.function.Function2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.List;

public class IMessageAggFunctionEnrich implements Function2<List<MessageEnrich>, List<MessageEnrich>, List<MessageEnrich>> {
    private static Logger log = LoggerFactory.getLogger(IMessageAggFunctionEnrich.class);

    @Override
    public List<MessageEnrich> call(List<MessageEnrich> mg_1, List<MessageEnrich> mg_2) {
        if (mg_1 == null) {
            return mg_2;
        }

        if (mg_2 == null) {
            return mg_1;
        }

        List<MessageEnrich> allmg = new ArrayList<>();
        allmg.addAll(mg_1);
        allmg.addAll(mg_2);
        return allmg;

    }

}
