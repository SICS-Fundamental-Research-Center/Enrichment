package sics.seiois.mlsserver.biz.der.enrich;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Utils {
    public Utils(){

    }

    public static ArrayList<String[]> generateTokens(String[] data, String limiter) {
        ArrayList<String[]> serialsTokens = new ArrayList<String[]>();
        for (String record : data) {
            String[] tokens = record.split(limiter);
            serialsTokens.add(tokens);
        }
        return serialsTokens;
    }

    public static void generateTokens(HashMap<Integer, String[]> dataTokens, HashMap<Integer, String> data, String limiter) {
        for (Map.Entry<Integer, String> entry : data.entrySet()) {
            String record = entry.getValue();
            String[] tokens = record.split(limiter);
            dataTokens.put(entry.getKey(), tokens);
        }
    }

    public static void randomChoose(int min, int max, int n, HashSet<Integer> set) {
        if (n > (max - min + 1) || max < min) {
            return;
        }
        for (int i = 0; i < n; i++) {
            int num = (int) (Math.random() * (max - min)) +min;
            set.add(num);
        }
        int _size = set.size();
        if (_size < n) {
            randomChoose(min, max, n - _size, set);
        }
    }


}
