package sics.seiois.mlsserver.biz.der.enrich;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sics.seiois.mlsserver.biz.der.enrich.graph.KGraph;
import sics.seiois.mlsserver.biz.der.enrich.message.MessageEnrich;
import sics.seiois.mlsserver.biz.der.enrich.table.Table;
import sics.seiois.mlsserver.biz.der.mining.Message;
import sics.seiois.mlsserver.model.SparkContextConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Enrich {
    private static final Logger logger = LoggerFactory.getLogger(Enrich.class);


    public static void main(String[] args) {
//        String config_file = "D:\\REE\\enrich\\datasets\\person_small\\config.json";
//        String config_file = "D:\\REE\\enrich\\datasets\\imdb\\config.json";
        String config_file = args[0];
        Config config = new Config(config_file);
        String table_file = config.getTablePath();
        String tableName = config.getTableName();
        String KG_file = config.getGraphFile();
        double simThreshold = config.getJaccThreshold();
        int K = 3; // the parameter of HER top-K

        // load table and graph
        logger.info("Start loading table...");
        Table table = new Table(tableName, table_file, config);
        logger.info("Start loading graph...");
        KGraph graph = new KGraph();
        graph.loadGraph(KG_file, config.getSampleRatioGraphBE());

        BatchEnrichmentParallel batchEnrichmentParallel = new BatchEnrichmentParallel(graph, table, config);
        batchEnrichmentParallel.prepareAuxStructure();
        long startMineTimeInc = System.currentTimeMillis();
//        List<MessageEnrich> messageEnriches = batchEnrichmentParallel.enrichmentParallel("111", null, null);
        List<MessageEnrich> messageEnriches = batchEnrichmentParallel.enrichmentParallelThread(K);
        long duringTime = System.currentTimeMillis() - startMineTimeInc;
        logger.info("The time of Batch Enrichment is " +  duringTime);

        // aggregate all enriched messages
        HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER_global = new HashMap<>();
        for (MessageEnrich messageEnrich: messageEnriches) {
            HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> her_topK = messageEnrich.getHER_topK();
            for (Map.Entry<Integer, ArrayList<ImmutablePair<Integer, Double>>> entry: her_topK.entrySet()) {
                int k = entry.getKey();
                ArrayList<ImmutablePair<Integer, Double>> arr = entry.getValue();
                if (HER_global.containsKey(k)) {
                    HER_global.get(k).addAll(arr);
                } else {
                    HER_global.put(k, arr);
                }
            }
        }
//        for (MessageEnrich messageEnrich: messageEnriches) {
//            HashMap<Integer, ImmutablePair<Integer, Double>> her = messageEnrich.getHER();
//            for (Map.Entry<Integer, ImmutablePair<Integer, Double>> entry: her.entrySet()) {
//                int k = entry.getKey();
//                int v = entry.getValue().getLeft();
//                double corr = entry.getValue().getRight();
//                if (HER_global.containsKey(k)) {
//                    if (corr > HER_global.get(k).getRight()) {
//                        HER_global.put(k, new ImmutablePair<>(v, corr));
//                    }
//                } else {
//                    HER_global.put(k, new ImmutablePair<>(v, corr));
//                }
//            }
//        }
//        if (config.ifIncEnrich()) {
//            IncreEnrichmentParallel increEnrichmentParallel = new IncreEnrichmentParallel(graph, table, config, HER_global);
//            increEnrichmentParallel.prepareAuxStructureInc(config.getSampleRatio());
//            startMineTimeInc = System.currentTimeMillis();
////            increEnrichmentParallel.incEnrichmentParallel("111", null, null);
//            increEnrichmentParallel.incEnrichmentParallelThread(K);
//            duringTime = System.currentTimeMillis() - startMineTimeInc;
//            logger.info("The time of Incremental Enrichment is " + duringTime);
//        }


        // new version; only for experiments; do not have actual use
        if (config.ifIncEnrich()) {
            double sampleRatio = config.getSampleRatio();
            double sampleRatioOne = sampleRatio;
            IncreEnrichmentParallel increEnrichmentParallel = new IncreEnrichmentParallel(graph, table, config, HER_global);
            increEnrichmentParallel.prepareAuxStructureInc(sampleRatioOne);

            long startMineTimeInc_ = 0;
            if (config.getIfIncIE() == 1) {
                startMineTimeInc_ = System.currentTimeMillis();
                increEnrichmentParallel.incEnrichmentParallelThread(K);
                long duringTimeInc_ = System.currentTimeMillis() - startMineTimeInc_;
                logger.info("Increment Enrichment Time of Graph Updates with {} : {}", sampleRatioOne, duringTimeInc_);

            } else {
                KGraph graph1 = increEnrichmentParallel.getUpdatedGraph();
                BatchEnrichmentParallel batchEnrichmentParallel1 = new BatchEnrichmentParallel(graph1, table, config);
                batchEnrichmentParallel1.prepareAuxStructure();
                startMineTimeInc_ = System.currentTimeMillis();
                List<MessageEnrich> messageEnriches1 = batchEnrichmentParallel1.enrichmentParallelThread(K);
                long duringTimeInc_ = System.currentTimeMillis() - startMineTimeInc_;
                logger.info("Incremental Enrichment of Graph Updates (using BE) with {} : {}", sampleRatioOne, duringTimeInc_);
            }

            // Table updates
            Table tableUpdate = new Table(config);
            KGraph graphUpdate = increEnrichmentParallel.getUpdatedGraph();
            tableUpdate.loadTable(tableName, table_file, config.getSampleRatioTableUpdateIE());
            BatchEnrichmentParallel batchEnrichmentParallelUpdate = new BatchEnrichmentParallel(graphUpdate, tableUpdate, config);
            batchEnrichmentParallelUpdate.prepareAuxStructure();
            long startMineTimeUpdate = System.currentTimeMillis();
            List<MessageEnrich> messageEnrichesUpdate = batchEnrichmentParallelUpdate.enrichmentParallelThread(K);
            long duringTimeUpdate = System.currentTimeMillis() - startMineTimeUpdate;
            logger.info("Incremental Enrichment Time of Table Updates with {} : {}", config.getSampleRatioTableUpdateIE(), duringTimeUpdate);

        }

//        // Batch enrichment
//        logger.info("Initialize BE...");
//        BatchEnrichment batchEnrichment = new BatchEnrichment(graph, table, config);
//        // run enrichment
//        logger.info("Construct Auxiliary structure...");
//        batchEnrichment.prepareAuxStructure();
//        logger.info("Start BE...");
//        batchEnrichment.enrichment();
//        logger.info("Load enriched table to file...");
//        table.saveEnrichedTable(config.getEnrichedTablePath());
//
//        if (config.ifIncEnrich()) {
//            logger.info("Initialize IE...");
//            IncreEnrichment increEnrichment = new IncreEnrichment(graph, table, config, batchEnrichment.getHER());
//            logger.info("Prepare update operations and update graph");
//            increEnrichment.prepareAuxStructureInc(config.getSampleRatio());
//            logger.info("Start IE...");
//            increEnrichment.incEnrichment();
//            logger.info("Load updated enriched table to file...");
//            table.saveEnrichedTable(config.getUpdatedEnrichedTablePath());
//        }


    }

}