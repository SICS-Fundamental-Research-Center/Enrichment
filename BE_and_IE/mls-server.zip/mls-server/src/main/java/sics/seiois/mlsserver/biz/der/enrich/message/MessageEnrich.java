package sics.seiois.mlsserver.biz.der.enrich.message;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.hadoop.util.hash.Hash;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class MessageEnrich implements Serializable {

    private static final long serialVersionUID = -1033110031256247070L;

    private int tupleIDStart;
    private int tupleIDEnd;
//    private HashMap<String, String[]> columnsMap;
    private HashMap<Integer, ImmutablePair<Integer, Double>> HER;
    private HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER_topK;

    public MessageEnrich (int tupleIDStart, int tupleIDEnd, HashMap<Integer, ImmutablePair<Integer, Double>> HER) {
        this.tupleIDStart = tupleIDStart;
        this.tupleIDEnd = tupleIDEnd;
//        this.columnsMap = columnsMap;
        this.HER = HER;
    }

    public MessageEnrich (int tupleIDStart, int tupleIDEnd, String option,
                          HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> HER_topK) {
        this.tupleIDStart = tupleIDStart;
        this.tupleIDEnd = tupleIDEnd;
//        this.columnsMap = columnsMap;
        this.HER_topK = HER_topK;
    }

    public HashMap<Integer, ImmutablePair<Integer, Double>> getHER() {
        return this.HER;
    }

    public HashMap<Integer, ArrayList<ImmutablePair<Integer, Double>>> getHER_topK() {
        return this.HER_topK;
    }

}
