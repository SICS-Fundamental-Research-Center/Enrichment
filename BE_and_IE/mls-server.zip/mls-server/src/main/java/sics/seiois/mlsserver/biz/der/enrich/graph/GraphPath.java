package sics.seiois.mlsserver.biz.der.enrich.graph;

import java.util.HashSet;
import java.util.LinkedList;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.io.*;
import java.util.stream.Collectors;

class GraphPath {
    private Vertex pivotal_vertex;
    private ArrayList<Edge> paths;

    public GraphPath(Vertex pivotal_vertex, ArrayList<Edge> paths) {
        this.pivotal_vertex = pivotal_vertex;
        this.paths = paths;
    }

    public String toAttribute() {
        String attr = "";
        for (Edge edge : this.paths) {
            attr += edge.getLabel() + " ";
        }
        return attr.trim();
    }

    /*
        Two options:
        1) "all": take all labels of passing vertices;
        2) "one": take the label of the last vertices;
     */
    public String toValue(String option) {
        String values = "";
        if (option.equals("all")) {
            for (Edge edge : this.paths) {
                values += edge.getDestVertex().getName();
            }
        } else if (option.equals("one")) {
//            values = this.paths.get(this.paths.size() - 1).getLabel();
        }
        return values.trim();
    }
}