#!/bin/bash
# 系统环境: dev，开发环境；test，测试环境；pro，正式环境；
APP_EVN="test"
#
